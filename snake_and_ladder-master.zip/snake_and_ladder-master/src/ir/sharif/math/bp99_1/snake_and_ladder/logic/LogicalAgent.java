package ir.sharif.math.bp99_1.snake_and_ladder.logic;


import ir.sharif.math.bp99_1.snake_and_ladder.graphic.GraphicalAgent;
import ir.sharif.math.bp99_1.snake_and_ladder.model.*;
import ir.sharif.math.bp99_1.snake_and_ladder.model.pieces.*;
import ir.sharif.math.bp99_1.snake_and_ladder.model.prizes.Prize;
import ir.sharif.math.bp99_1.snake_and_ladder.model.transmitters.DeadlySnake;
import ir.sharif.math.bp99_1.snake_and_ladder.model.transmitters.Earthworm;
import ir.sharif.math.bp99_1.snake_and_ladder.model.transmitters.MagicSnake;
import ir.sharif.math.bp99_1.snake_and_ladder.model.transmitters.Transmitter;

import java.io.*;
import java.util.*;

/**
 * This class is an interface between logic and graphic.
 * some methods of this class, is called from graphic.
 * DO NOT CHANGE ANY PART WHICH WE MENTION.
 */
public class LogicalAgent {
    private final ModelLoader modelLoader;
    private final GraphicalAgent graphicalAgent;
    private final GameState gameState;

    /**
     * DO NOT CHANGE CONSTRUCTOR.
     */
    public LogicalAgent() {
        this.graphicalAgent = new GraphicalAgent(this);
        this.modelLoader = new ModelLoader();
        this.gameState = loadGameState(); //exception
    }


    /**
     * NO CHANGES NEEDED.
     */

    private GameState loadGameState() {
        Board board = modelLoader.loadBord();
        Player player1 = modelLoader.loadPlayer(graphicalAgent.getPlayerNames(1), 1);
        Player player2;
        do {
            player2 = modelLoader.loadPlayer(graphicalAgent.getPlayerNames(2), 2);
        } while (player1.equals(player2));
        player1.setRival(player2);
        player2.setRival(player1);
        GameState gs= new GameState(board,player1,player2);

        for (File f: Objects.requireNonNull(this.modelLoader.getBoardFile().getParentFile().listFiles())) {
            if (f.getName().equals(player1.getName()+"-"+player2.getName()+".txt")){
                gs=load_game_state(f,player1.getName(),player2.getName());
                break;
            }
        }
        return gs;
    }


    /**
     * NO CHANGES NEEDED.
     */
    public void initialize() {
        graphicalAgent.initialize(gameState);
    }

    /**
     * Give a number from graphic,( which is the playerNumber of a player
     * who clicks "ReadyButton".) you should somehow change that player state.
     * if both players are ready. then start the game.
     */
    public void readyPlayer(int playerNumber) {
        this.gameState.getPlayer(playerNumber).setReady(!this.gameState.getPlayer(playerNumber).isReady());
        if (this.gameState.getPlayer1().isReady() && this.gameState.getPlayer2().isReady()) {
            this.gameState.nextTurn();
            for (Cell c : this.gameState.getBoard().getStartingCells().keySet()) {
                if (this.gameState.getBoard().getStartingCells().get(c) == 10){
                    c.setPiece(this.gameState.getPlayer1().getBomberPiece());
                    c.setBomberPiece(this.gameState.getPlayer(1).getBomberPiece());
                    this.gameState.getPlayer(1).getBomberPiece().setCurrentCell(c);
                }
                if (this.gameState.getBoard().getStartingCells().get(c) == 11){
                    c.setPiece(this.gameState.getPlayer1().getThiefPiece());
                    c.setThiefPiece(this.gameState.getPlayer(1).getThiefPiece());
                    this.gameState.getPlayer(1).getThiefPiece().setCurrentCell(c);
                }
                if (this.gameState.getBoard().getStartingCells().get(c) == 12){
                    c.setPiece(this.gameState.getPlayer1().getHealerPiece());
                    c.setHealerPiece(this.gameState.getPlayer(1).getHealerPiece());
                    this.gameState.getPlayer(1).getHealerPiece().setCurrentCell(c);
                }
                if (this.gameState.getBoard().getStartingCells().get(c) == 13){
                    c.setPiece(this.gameState.getPlayer1().getSniperPiece());
                    c.setSniperPiece(this.gameState.getPlayer(1).getSniperPiece());
                    this.gameState.getPlayer(1).getSniperPiece().setCurrentCell(c);
                }
                if (this.gameState.getBoard().getStartingCells().get(c) == 20){
                    c.setPiece(this.gameState.getPlayer2().getBomberPiece());
                    c.setBomberPiece(this.gameState.getPlayer(2).getBomberPiece());
                    this.gameState.getPlayer(2).getBomberPiece().setCurrentCell(c);
                }
                if (this.gameState.getBoard().getStartingCells().get(c) == 21){
                    c.setPiece(this.gameState.getPlayer2().getThiefPiece());
                    c.setThiefPiece(this.gameState.getPlayer(2).getThiefPiece());
                    this.gameState.getPlayer(2).getThiefPiece().setCurrentCell(c);
                }
                if (this.gameState.getBoard().getStartingCells().get(c) == 22){
                    c.setPiece(this.gameState.getPlayer2().getHealerPiece());
                    c.setHealerPiece(this.gameState.getPlayer(2).getHealerPiece());
                    this.gameState.getPlayer(2).getHealerPiece().setCurrentCell(c);
                }
                if (this.gameState.getBoard().getStartingCells().get(c) == 23){
                    c.setPiece(this.gameState.getPlayer2().getSniperPiece());
                    c.setSniperPiece(this.gameState.getPlayer(2).getSniperPiece());
                    this.gameState.getPlayer(2).getSniperPiece().setCurrentCell(c);
                }
            }
            this.SaveGameState();
        }
            // dont touch this line
            graphicalAgent.update(gameState);
    }

    /**
     * give x,y (coordinates of a cell) :
     * you should handle if user want to select a piece
     * or already selected a piece and now want to move it to a new cell
     */
    // ***
    public void selectCell(int x, int y) {
        this.SaveGameState();
        Cell cell=this.gameState.getBoard().getCell(x,y);
        if (cell.getPiece()!=null){System.out.println(cell.getPiece().isDead());}
        if (this.gameState.getCurrentPlayer().isReady()) {
            if (this.gameState.getCurrentPlayer().isDicePlayedThisTurn()) {
                if (cell.getPiece() == null) {
                    if (this.gameState.getCurrentPlayer().getSelectedPiece() != null) {
                        System.out.println(this.gameState.getCurrentPlayer().getSelectedPiece().isDead());
                        if (this.gameState.getCurrentPlayer().getSelectedPiece().isValidMove(cell, this.gameState.getCurrentPlayer().getMoveLeft(), this.gameState.getBoard())) {
                            if (!this.gameState.getCurrentPlayer().getSelectedPiece().isDead()){
                                this.gameState.getCurrentPlayer().getSelectedPiece().moveTo(cell);
                                this.gameState.getCurrentPlayer().getHealerPiece().HealThePiece(this.gameState.getBoard());
                                this.gameState.getCurrentPlayer().getSniperPiece().ShootThePiece(this.gameState.getBoard());
                            }
                            if (this.gameState.getCurrentPlayer().getSelectedPiece().getColor().equals(Color.RED)){
                                if (!this.gameState.getCurrentPlayer().getSelectedPiece().isDead()){
                                    this.gameState.getCurrentPlayer().getBomberPiece().moveTo(cell);
                                    this.gameState.getCurrentPlayer().getHealerPiece().HealThePiece(this.gameState.getBoard());
                                    this.gameState.getCurrentPlayer().getSniperPiece().ShootThePiece(this.gameState.getBoard());
                                }
                            }
                            if (this.gameState.getCurrentPlayer().getSelectedPiece().getColor().equals(Color.BLUE)){
                                if (!this.gameState.getCurrentPlayer().getSelectedPiece().isDead()){
                                    this.gameState.getCurrentPlayer().getThiefPiece().moveTo(cell);
                                    this.gameState.getCurrentPlayer().getHealerPiece().HealThePiece(this.gameState.getBoard());
                                    this.gameState.getCurrentPlayer().getSniperPiece().ShootThePiece(this.gameState.getBoard());
                                }
                            }
                            if (this.gameState.getCurrentPlayer().getSelectedPiece().getColor().equals(Color.GREEN)){
                                this.gameState.getCurrentPlayer().getHealerPiece().moveTo(cell);
                                this.gameState.getCurrentPlayer().getHealerPiece().HealThePiece(this.gameState.getBoard());
                                this.gameState.getCurrentPlayer().getSniperPiece().ShootThePiece(this.gameState.getBoard());
                            }
                            if (this.gameState.getCurrentPlayer().getSelectedPiece().getColor().equals(Color.YELLOW)){
                                if (!this.gameState.getCurrentPlayer().getSelectedPiece().isDead()){
                                    this.gameState.getCurrentPlayer().getSniperPiece().moveTo(cell);
                                    this.gameState.getCurrentPlayer().getHealerPiece().HealThePiece(this.gameState.getBoard());
                                    this.gameState.getCurrentPlayer().getSniperPiece().ShootThePiece(this.gameState.getBoard());
                                }
                            }
                            if (cell.getPrize()!=null){
                                if (cell.getThiefPiece()==null){
                                    cell.getPrize().using(cell.getPiece());
                                }
                                else {
                                    if (cell.getThiefPiece().getPrize()==null){
                                        cell.getPrize().using(cell.getPiece());
                                    }
                                }
                            }
                            if (cell.getTransmitter()!=null){
                                if (cell.getPiece().getColor().equals(Color.BLUE)){cell.getThiefPiece().setPrize(null);}
                                if (cell.getDeadlySnake()!=null){
                                    Piece p= cell.getPiece();
                                    cell.getDeadlySnake().transmit(p);
                                    p.KillThePiece();
                                }
                                if (cell.getEarthworm()!=null){cell.getEarthworm().differenttransmit(cell.getPiece(),this.gameState.getBoard());}
                                if (cell.getMagicSnake()!=null){cell.getMagicSnake().transmit(cell.getPiece());}
                                if (cell.getDeadlySnake()==null && cell.getEarthworm()==null && cell.getMagicSnake()==null){cell.getTransmitter().transmit(cell.getPiece());}
                            }
                            this.gameState.nextTurn();
                        }
                    }
                }
                else {
                    if (this.gameState.getCurrentPlayer().getSelectedPiece() == null) {
                        if (this.gameState.getCurrentPlayer().getPieces().contains(cell.getPiece())){
                            this.gameState.getCurrentPlayer().setSelectedPiece(cell.getPiece());
                            if (cell.getPiece().getColor().equals(Color.RED)){
                                this.gameState.getCurrentPlayer().setSelectedPiece(this.gameState.getCurrentPlayer().getBomberPiece());
                                this.gameState.getCurrentPlayer().getBomberPiece().setSelected(true);
                            }
                            if (cell.getPiece().getColor().equals(Color.BLUE)){
                                this.gameState.getCurrentPlayer().setSelectedPiece(this.gameState.getCurrentPlayer().getThiefPiece());
                                this.gameState.getCurrentPlayer().getThiefPiece().setSelected(true);
                            }
                            if (cell.getPiece().getColor().equals(Color.GREEN)){
                                this.gameState.getCurrentPlayer().setSelectedPiece(this.gameState.getCurrentPlayer().getHealerPiece());
                                this.gameState.getCurrentPlayer().getHealerPiece().setSelected(true);
                            }
                            if (cell.getPiece().getColor().equals(Color.YELLOW)){
                                this.gameState.getCurrentPlayer().setSelectedPiece(this.gameState.getCurrentPlayer().getSniperPiece());
                                this.gameState.getCurrentPlayer().getSniperPiece().setSelected(true);
                            }
                            cell.getPiece().setSelected(true);
                        }
                    }
                    else { //جدید
                        if (this.gameState.getCurrentPlayer().getSelectedPiece().equals(cell.getPiece())){
                            if (cell.getPiece().getColor().equals(Color.BLUE) && cell.getPrize()!=null){
                                if (this.gameState.getCurrentPlayer().getThiefPiece().getPrize()==null) {
                                    this.gameState.getCurrentPlayer().getThiefPiece().setPrize(cell.getPrize());
                                    cell.getPrize().setThiefPiece(this.gameState.getCurrentPlayer().getThiefPiece());
                                    cell.getPrize().setCell(null);
                                    cell.setPrize(null);
                                    this.gameState.nextTurn();
                                }
                            }
                            if (cell.getPiece().getColor().equals(Color.RED)){
                                if (!this.gameState.getCurrentPlayer().getBomberPiece().isDead()){
                                    if (this.gameState.getCurrentPlayer().getBomberPiece().isBombing()){
                                        this.gameState.getCurrentPlayer().getBomberPiece().DetonateTheBomb(this.gameState.getBoard());
                                        this.gameState.getCurrentPlayer().getBomberPiece().setBombing(false);
                                        this.gameState.nextTurn();
                                    }
                                }
                            }
                            if (cell.getPiece().getColor().equals(Color.BLUE) && this.gameState.getCurrentPlayer().getThiefPiece().getPrize()!=null){
                                cell.setPrize(null);
                                cell.setPrize(this.gameState.getCurrentPlayer().getThiefPiece().getPrize());
                                this.gameState.getCurrentPlayer().getThiefPiece().getPrize().setCell(cell);
                                this.gameState.getCurrentPlayer().getThiefPiece().getPrize().setThiefPiece(null);
                                this.gameState.getCurrentPlayer().getThiefPiece().setPrize(null);
                                this.gameState.nextTurn();
                            }
                        }
                        else {
                            if (this.gameState.getCurrentPlayer().getPieces().contains(cell.getPiece())){
                                this.gameState.getCurrentPlayer().getSelectedPiece().setSelected(false); //جدید
                                this.gameState.getCurrentPlayer().setSelectedPiece(cell.getPiece());
                                if (cell.getPiece().getColor().equals(Color.RED)){
                                    this.gameState.getCurrentPlayer().setSelectedPiece(this.gameState.getCurrentPlayer().getBomberPiece());
                                    this.gameState.getCurrentPlayer().getBomberPiece().setSelected(true);
                                }
                                if (cell.getPiece().getColor().equals(Color.BLUE)){
                                    this.gameState.getCurrentPlayer().setSelectedPiece(this.gameState.getCurrentPlayer().getThiefPiece());
                                    this.gameState.getCurrentPlayer().getThiefPiece().setSelected(true);
                                }
                                if (cell.getPiece().getColor().equals(Color.GREEN)){
                                    this.gameState.getCurrentPlayer().setSelectedPiece(this.gameState.getCurrentPlayer().getHealerPiece());
                                    this.gameState.getCurrentPlayer().getHealerPiece().setSelected(true);
                                }
                                if (cell.getPiece().getColor().equals(Color.YELLOW)){
                                    this.gameState.getCurrentPlayer().setSelectedPiece(this.gameState.getCurrentPlayer().getSniperPiece());
                                    this.gameState.getCurrentPlayer().getSniperPiece().setSelected(true);
                                }
                                cell.getPiece().setSelected(true);
                            }
                        }
                    }
                }
            }
        }
        this.SaveGameState();
        // dont touch this line
        graphicalAgent.update(gameState);
        checkForEndGame();
    }

    /**
     * check for endgame and specify winner
     * if player one in winner set winner variable to 1
     * if player two in winner set winner variable to 2
     * If the game is a draw set winner variable to 3
     */
    private void checkForEndGame() {
        int a= this.gameState.getTurn();
        if (a==41) {
            this.gameState.getPlayer1().setReady(false);
            this.gameState.getPlayer2().setReady(false);
            // game ends
            int winner = 1;
            if (this.gameState.getPlayer1().getScore()<this.gameState.getPlayer2().getScore()){
                winner=2;
            }
            if (this.gameState.getPlayer1().getScore()==this.gameState.getPlayer2().getScore()){
                winner=3;
            }
            for (File f: Objects.requireNonNull(this.modelLoader.getBoardFile().getParentFile().listFiles())) {
                if (f.getName().equals(this.gameState.getPlayer1().getName()+"-"+this.gameState.getPlayer2().getName()+".txt")){
                    f.delete();
                    break;
                }
            }
            // your code
            // dont touch it
            graphicalAgent.playerWin(winner);
            /* save players*/
            modelLoader.savePlayer(gameState.getPlayer1());
            modelLoader.savePlayer(gameState.getPlayer2());
            modelLoader.archive(gameState.getPlayer1(), gameState.getPlayer2());
            LogicalAgent logicalAgent = new LogicalAgent(); //exception
            logicalAgent.initialize();
        }
    }
    /**
     * Give a number from graphic,( which is the playerNumber of a player
     * who left clicks "dice button".) you should roll his/her dice
     * and update *****************
     */
    public void rollDice(int playerNumber) {
        this.SaveGameState();
        if (this.gameState.getPlayer(playerNumber).equals(this.gameState.getCurrentPlayer())) {
            if (!this.gameState.getPlayer(playerNumber).isDicePlayedThisTurn()) {
                int dicenumber = this.gameState.getPlayer(playerNumber).getDice().roll();
                this.gameState.getMap().put(this.gameState.getTurn(),dicenumber); //اضافه
                this.gameState.getPlayer(playerNumber).setMoveLeft(dicenumber);
                this.gameState.getPlayer(playerNumber).setDicePlayedThisTurn(true);
                if (this.gameState.getTurn()>2){
                    if (this.gameState.getMap().get(this.gameState.getTurn()).equals(this.gameState.getMap().get(this.gameState.getTurn() - 2))){
                        this.gameState.getCurrentPlayer().getDice().addChance(this.gameState.getMap().get(this.gameState.getTurn()),1);
                    }
                }
                if (dicenumber == 2){
                    this.gameState.getCurrentPlayer().getDice().setChance1(1);
                    this.gameState.getCurrentPlayer().getDice().setChance2(1);
                    this.gameState.getCurrentPlayer().getDice().setChance3(1);
                    this.gameState.getCurrentPlayer().getDice().setChance4(1);
                    this.gameState.getCurrentPlayer().getDice().setChance5(1);
                    this.gameState.getCurrentPlayer().getDice().setChance6(1);
                }
                if (dicenumber == 1) {
                    if (!this.gameState.getPlayer(playerNumber).getHealerPiece().isDead()){
                        this.gameState.getPlayer(playerNumber).getHealerPiece().setHealing(true);
                        this.gameState.getPlayer(playerNumber).getHealerPiece().HealThePiece(this.gameState.getBoard());
                    }
                }
                if (dicenumber == 3) {
                    if (!this.gameState.getPlayer(playerNumber).getBomberPiece().isDead()){
                        this.gameState.getPlayer(playerNumber).getBomberPiece().setBombing(true);
                    }
                }
                if (dicenumber == 5) {
                    if (!this.gameState.getPlayer(playerNumber).getSniperPiece().isDead()){
                        this.gameState.getPlayer(playerNumber).getSniperPiece().setSniping(true);
                        this.gameState.getPlayer(playerNumber).getSniperPiece().ShootThePiece(this.gameState.getBoard());
                    }
                }
                if (dicenumber == 6) {
                    this.gameState.getPlayer(playerNumber).setScore(this.gameState.getPlayer(playerNumber).getScore() + 4);
                }
                if (!this.gameState.getPlayer(playerNumber).hasMove(this.gameState.getBoard(), dicenumber)) {
                    this.gameState.getPlayer(playerNumber).setScore(this.gameState.getPlayer(playerNumber).getScore() - 3);
                    this.gameState.nextTurn();
                }
            }
        }
        this.SaveGameState();
        // dont touch this line
        graphicalAgent.update(gameState);
    }

    public void SaveGameState() {
        try {
            String path = this.modelLoader.getPlayersDirectory().getParent()+"\\"+ this.gameState.getPlayer1().getName() + "-" + this.gameState.getPlayer2().getName()+".txt";
            File f = new File(path);
            f.getParentFile().mkdirs();
            if (!f.exists()) {
                f.createNewFile();
            }

            FileOutputStream fout= new FileOutputStream(f,false);
            PrintStream out= new PrintStream(fout);

            out.println("CELLS[ 7 16 ]:");
            for (int i = 1; i < 8; i++) {
                for (int j = 1; j < 17; j++) {
                    if (j==16){out.print(this.gameState.getBoard().getCell(i,j).getColor().toString());}
                    else {out.print(this.gameState.getBoard().getCell(i,j).getColor().toString()+" ");}
                }
                out.println("");
            }

            out.println("");
            out.println("STARTING_CELLS[ 8 ]:");

            out.print(this.gameState.getPlayer1().getBomberPiece().getCurrentCell().getX()+" ");
            out.print(this.gameState.getPlayer1().getBomberPiece().getCurrentCell().getY()+" ");
            out.println(10);

            out.print(this.gameState.getPlayer1().getThiefPiece().getCurrentCell().getX()+" ");
            out.print(this.gameState.getPlayer1().getThiefPiece().getCurrentCell().getY()+" ");
            out.println(11);

            out.print(this.gameState.getPlayer1().getHealerPiece().getCurrentCell().getX()+" ");
            out.print(this.gameState.getPlayer1().getHealerPiece().getCurrentCell().getY()+" ");
            out.println(12);

            out.print(this.gameState.getPlayer1().getSniperPiece().getCurrentCell().getX()+" ");
            out.print(this.gameState.getPlayer1().getSniperPiece().getCurrentCell().getY()+" ");
            out.println(13);


            out.print(this.gameState.getPlayer2().getBomberPiece().getCurrentCell().getX()+" ");
            out.print(this.gameState.getPlayer2().getBomberPiece().getCurrentCell().getY()+" ");
            out.println(20);

            out.print(this.gameState.getPlayer2().getThiefPiece().getCurrentCell().getX()+" ");
            out.print(this.gameState.getPlayer2().getThiefPiece().getCurrentCell().getY()+" ");
            out.println(21);

            out.print(this.gameState.getPlayer2().getHealerPiece().getCurrentCell().getX()+" ");
            out.print(this.gameState.getPlayer2().getHealerPiece().getCurrentCell().getY()+" ");
            out.println(22);

            out.print(this.gameState.getPlayer2().getSniperPiece().getCurrentCell().getX()+" ");
            out.print(this.gameState.getPlayer2().getSniperPiece().getCurrentCell().getY()+" ");
            out.println(23);

            out.println("");
            out.println("WALLS[ 46 ]:");
            for (int i = 0; i < 46; i++) {
                out.print(this.gameState.getBoard().getWalls().get(i).getCell1().getX()+" ");
                out.print(this.gameState.getBoard().getWalls().get(i).getCell1().getY()+" ");
                out.print(this.gameState.getBoard().getWalls().get(i).getCell2().getX()+" ");
                out.println(this.gameState.getBoard().getWalls().get(i).getCell2().getY());
            }

            out.println("");
            out.println("TRANSMITTERS[ 12 ]:");
            for (int i = 1; i < 8; i++) {
                for (int j = 1; j < 17; j++) {
                    if (this.gameState.getBoard().getCell(i,j).getDeadlySnake()!=null){
                        out.print(i+" "+j+" ");
                        out.print(this.gameState.getBoard().getCell(i,j).getDeadlySnake().getLastCell().getX()+" ");
                        out.print(this.gameState.getBoard().getCell(i,j).getDeadlySnake().getLastCell().getY()+" ");
                        out.println("D");
                    }
                    if (this.gameState.getBoard().getCell(i,j).getEarthworm()!=null){
                        out.print(i+" "+j+" "+i+" "+j+" ");
                        out.println("E");
                    }
                    if (this.gameState.getBoard().getCell(i,j).getMagicSnake()!=null){
                        out.print(i+" "+j+" ");
                        out.print(this.gameState.getBoard().getCell(i,j).getMagicSnake().getLastCell().getX()+" ");
                        out.print(this.gameState.getBoard().getCell(i,j).getMagicSnake().getLastCell().getY()+" ");
                        out.println("M");
                    }
                    if (this.gameState.getBoard().getCell(i,j).getDeadlySnake()==null){
                        if (this.gameState.getBoard().getCell(i,j).getEarthworm()==null){
                            if (this.gameState.getBoard().getCell(i,j).getMagicSnake()==null){
                                if (this.gameState.getBoard().getCell(i,j).getTransmitter()!=null){
                                    out.print(i+" "+j+" ");
                                    out.print(this.gameState.getBoard().getCell(i,j).getTransmitter().getLastCell().getX()+" ");
                                    out.print(this.gameState.getBoard().getCell(i,j).getTransmitter().getLastCell().getY()+" ");
                                    out.println("T");
                                }
                            }
                        }
                    }
                }
            }

            out.println("");
            out.println("PRIZES[ "+this.gameState.NumberOfPrizes()+" ]:");

            for (int i = 1; i < 8; i++) {
                for (int j = 1; j < 17; j++) {
                    if (this.gameState.getBoard().getCell(i,j).getPrize()!=null){
                        Prize p= this.gameState.getBoard().getCell(i,j).getPrize();
                        out.print(i+" "+j+" "+p.getPoint()+" "+p.getChance()+" "+p.getDiceNumber());
                        out.println("");
                    }
                }
            }
            if (this.gameState.getPlayer1().getThiefPiece().getPrize()!=null){
                Prize p_1= this.gameState.getPlayer1().getThiefPiece().getPrize();
                out.println(0+" "+0+" "+p_1.getPoint()+" "+p_1.getChance()+" "+p_1.getDiceNumber());
            }
            if (this.gameState.getPlayer2().getThiefPiece().getPrize()!=null){
                Prize p_2= this.gameState.getPlayer2().getThiefPiece().getPrize();
                out.println(0+" "+0+" "+p_2.getPoint()+" "+p_2.getChance()+" "+p_2.getDiceNumber());
            }

            out.println("");
            out.println(this.gameState.getPlayer1().getName());
            out.println(this.gameState.getPlayer1().getScore());
            out.println(this.gameState.getPlayer1().getId());
            out.println(this.gameState.getPlayer1().isReady());
            out.println(this.gameState.getPlayer1().isDicePlayedThisTurn());
            out.println(this.gameState.getPlayer1().getMoveLeft());

            out.print(this.gameState.getPlayer1().getDice().getChance1()+" ");
            out.print(this.gameState.getPlayer1().getDice().getChance2()+" ");
            out.print(this.gameState.getPlayer1().getDice().getChance3()+" ");
            out.print(this.gameState.getPlayer1().getDice().getChance4()+" ");
            out.print(this.gameState.getPlayer1().getDice().getChance5()+" ");
            out.println(this.gameState.getPlayer1().getDice().getChance6());

            out.println(this.gameState.getPlayer1().getBomberPiece().isDead());
            out.println(this.gameState.getPlayer1().getBomberPiece().isBombing());

            out.println(this.gameState.getPlayer1().getHealerPiece().isDead());
            out.println(this.gameState.getPlayer1().getHealerPiece().isHealing());

            out.println(this.gameState.getPlayer1().getSniperPiece().isDead());
            out.println(this.gameState.getPlayer1().getSniperPiece().isSniping());

            out.println(this.gameState.getPlayer1().getThiefPiece().isDead());
            out.println(this.gameState.getPlayer1().getThiefPiece().isStealing());

            if (this.gameState.getTurn()%2==0){out.println("null");}
            if (this.gameState.getTurn()%2!=0){
                if (this.gameState.getPlayer1().getBomberPiece().isSelected()){out.println("BomberPiece");}
                if (this.gameState.getPlayer1().getHealerPiece().isSelected()){out.println("HealerPiece");}
                if (this.gameState.getPlayer1().getSniperPiece().isSelected()){out.println("SniperPiece");}
                if (this.gameState.getPlayer1().getThiefPiece().isSelected()){out.println("ThiefPiece");}
                if (this.gameState.getPlayer1().getSelectedPiece()==null){out.println("null");}
            }

            if (this.gameState.getPlayer1().getThiefPiece().getPrize()==null){out.println("null");}
            else {
                out.print(this.gameState.getPlayer1().getThiefPiece().getPrize().getPoint()+" ");
                out.print(this.gameState.getPlayer1().getThiefPiece().getPrize().getChance()+" ");
                out.println(this.gameState.getPlayer1().getThiefPiece().getPrize().getDiceNumber());
            }

            out.println("");
            out.println(this.gameState.getPlayer2().getName());
            out.println(this.gameState.getPlayer2().getScore());
            out.println(this.gameState.getPlayer2().getId());
            out.println(this.gameState.getPlayer2().isReady());
            out.println(this.gameState.getPlayer2().isDicePlayedThisTurn());
            out.println(this.gameState.getPlayer2().getMoveLeft());

            out.print(this.gameState.getPlayer2().getDice().getChance1()+" ");
            out.print(this.gameState.getPlayer2().getDice().getChance2()+" ");
            out.print(this.gameState.getPlayer2().getDice().getChance3()+" ");
            out.print(this.gameState.getPlayer2().getDice().getChance4()+" ");
            out.print(this.gameState.getPlayer2().getDice().getChance5()+" ");
            out.println(this.gameState.getPlayer2().getDice().getChance6());

            out.println(this.gameState.getPlayer2().getBomberPiece().isDead());
            out.println(this.gameState.getPlayer2().getBomberPiece().isBombing());

            out.println(this.gameState.getPlayer2().getHealerPiece().isDead());
            out.println(this.gameState.getPlayer2().getHealerPiece().isHealing());

            out.println(this.gameState.getPlayer2().getSniperPiece().isDead());
            out.println(this.gameState.getPlayer2().getSniperPiece().isSniping());

            out.println(this.gameState.getPlayer2().getThiefPiece().isDead());
            out.println(this.gameState.getPlayer2().getThiefPiece().isStealing());

            if (this.gameState.getTurn()%2!=0){out.println("null");}
            if (this.gameState.getTurn()%2==0){
                if (this.gameState.getPlayer2().getBomberPiece().isSelected()){out.println("BomberPiece");}
                if (this.gameState.getPlayer2().getHealerPiece().isSelected()){out.println("HealerPiece");}
                if (this.gameState.getPlayer2().getSniperPiece().isSelected()){out.println("SniperPiece");}
                if (this.gameState.getPlayer2().getThiefPiece().isSelected()){out.println("ThiefPiece");}
                if (this.gameState.getPlayer2().getSelectedPiece()==null){out.println("null");}
            }

            if (this.gameState.getPlayer2().getThiefPiece().getPrize()==null){out.println("null");}
            else {
                out.print(this.gameState.getPlayer2().getThiefPiece().getPrize().getPoint()+" ");
                out.print(this.gameState.getPlayer2().getThiefPiece().getPrize().getChance()+" ");
                out.println(this.gameState.getPlayer2().getThiefPiece().getPrize().getDiceNumber());
            }

            out.println("");
            out.println(this.gameState.getTurn());

            out.flush();
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }


    public GameState load_game_state(File file, String namep1, String namep2) {
        try {
            Board board= new Board();

        int a = 0;
        int row = 0;
        int column = 0;
        int tedadmohre = 0;
        int tedaddivar = 0;
        int tedadmar = 0;
        int tedadjayeze = 0;

        String name1 = namep1;
        int score1 = 0;
        int id1 = 0;
        boolean ready1 = false;
        boolean tas_andakhte1 = false;
        int tas1 = 0;
        int c1 = 1, c2 = 1, c3 = 1, c4 = 1, c5 = 1, c6 = 1;
        boolean bp1_isDead = false;
        boolean bp1_isBombing = false;
        boolean hp1_isDead = false;
        boolean hp1_isHealing = false;
        boolean sp1_isDead = false;
        boolean sp1_isSniping = false;
        boolean tp1_isDead = false;
        boolean tp1_isStealing = false;
        boolean mohre1 = false;
        boolean bp1 = false;
        boolean hp1 = false;
        boolean sp1 = false;
        boolean tp1 = false;
        int point_1 = 0;
        int chance1 = 0;
        int dice_number1 = 0;
        boolean jayeze_dare1= true;

        String name2 = namep2;
        int score2 = 0;
        int id2 = 0;
        boolean ready2 = false;
        boolean tas_andakhte2 = false;
        int tas2 = 0;
        int ch1 = 1, ch2 = 1, ch3 = 1, ch4 = 1, ch5 = 1, ch6 = 1;
        boolean bp2_isDead = false;
        boolean bp2_isBombing = false;
        boolean hp2_isDead = false;
        boolean hp2_isHealing = false;
        boolean sp2_isDead = false;
        boolean sp2_isSniping = false;
        boolean tp2_isDead = false;
        boolean tp2_isStealing = false;
        boolean mohre2 = false;
        boolean bp2 = false;
        boolean hp2 = false;
        boolean sp2 = false;
        boolean tp2 = false;
        int point_2 = 0;
        int chance2 = 0;
        int dice_number2 = 0;
        boolean jayeze_dare2= true;

        int turn = 0;

        List<Cell> list = new LinkedList<>();
        Map<Cell, Integer> map = new HashMap<>();
        List<Wall> walls = new LinkedList<>();
        List<Transmitter> transmitters = new LinkedList<>();

        Scanner scanner = new Scanner(file);
            while (scanner.hasNext()) {
                String s = scanner.nextLine();
                if (a == 0) {
                    String s1 = s.substring(7);
                    row = Integer.parseInt(s1.substring(0, s1.indexOf(' ')));
                    String s2 = s1.substring(s1.indexOf(' ') + 1);
                    column = Integer.parseInt(s2.substring(0, s2.indexOf(' ')));
                }
                if (a > 0 && a < 8) {
                    String string = s;
                    String s1 = "";
                    for (int i = 1; i < 17; i++) {    //+1
                        Cell cell;
                        if (i != 16) {
                            s1 = string.substring(0, string.indexOf(' '));
                        }
                        if (i == 16) {
                            s1 = string.substring(0);
                        }
                        if (s1.equals("WHITE")) {
                            cell = new Cell(Color.WHITE, a, i);
                            list.add(cell);
                        }
                        if (s1.equals("BLACK")) {
                            cell = new Cell(Color.BLACK, a, i);
                            list.add(cell);
                        }
                        if (s1.equals("BLUE")) {
                            cell = new Cell(Color.BLUE, a, i);
                            list.add(cell);
                        }
                        if (s1.equals("RED")) {
                            cell = new Cell(Color.RED, a, i);
                            list.add(cell);
                        }
                        if (s1.equals("GREEN")) {
                            cell = new Cell(Color.GREEN, a, i);
                            list.add(cell);
                        }
                        if (s1.equals("YELLOW")) {
                            cell = new Cell(Color.YELLOW, a, i);
                            list.add(cell);
                        }
                        string = string.substring(string.indexOf(' ') + 1);
                    }
                }
                if (a == 9) {
                    String w1 = s.substring(16);
                    tedadmohre = Integer.parseInt(w1.substring(0, w1.indexOf(' ')));
                }
                if (a > 9 && a < 18) {
                    String s1 = s.substring(0, s.indexOf(' '));
                    int x = Integer.parseInt(s1);
                    String ss = s.substring(s.indexOf(' ') + 1);
                    String s2 = ss.substring(0, ss.indexOf(' '));
                    int y = Integer.parseInt(s2);
                    String sss = ss.substring(ss.indexOf(' ') + 1);
                    int pn = Integer.parseInt(sss);
                    Cell cell = list.get((x - 1) * column + y - 1);
                    map.put(cell, pn);
                }
                if (a == 19) {
                    String e1 = s.substring(7);
                    tedaddivar = Integer.parseInt(e1.substring(0, e1.indexOf(' ')));
                }
                if (a > 19 && a < 66) {
                    String t1 = s.substring(0, s.indexOf(' '));
                    int x1 = Integer.parseInt(t1);
                    String ss = s.substring(s.indexOf(' ') + 1);
                    String t2 = ss.substring(0, ss.indexOf(' '));
                    int y1 = Integer.parseInt(t2);
                    String sss = ss.substring(ss.indexOf(' ') + 1);
                    String t3 = sss.substring(0, sss.indexOf(' '));
                    int x2 = Integer.parseInt(t3);
                    String ssss = sss.substring(sss.indexOf(' ') + 1);
                    int y2 = Integer.parseInt(ssss);
                    Cell cell1 = list.get((x1 - 1) * column + y1 - 1);
                    Cell cell2 = list.get((x2 - 1) * column + y2 - 1);
                    Wall wall = new Wall(cell1, cell2);
                    walls.add(wall);
                }
                if (a == 67) {
                    String u = s.substring(14);
                    tedadmar = Integer.parseInt(u.substring(0, u.indexOf(' ')));
                }
                if (a > 67 && a < 80) {
                    String t1 = s.substring(0, s.indexOf(' '));
                    int x1 = Integer.parseInt(t1);
                    String ss = s.substring(s.indexOf(' ') + 1);
                    String t2 = ss.substring(0, ss.indexOf(' '));
                    int y1 = Integer.parseInt(t2);
                    String sss = ss.substring(ss.indexOf(' ') + 1);
                    String t3 = sss.substring(0, sss.indexOf(' '));
                    int x2 = Integer.parseInt(t3);
                    String ssss = sss.substring(sss.indexOf(' ') + 1);
                    String t4 = ssss.substring(0, ssss.indexOf(' ')); //اضافه کردم
                    int y2 = Integer.parseInt(t4); //تو پرانتز t4 گذاشتم
                    String sssss = ssss.substring(ssss.indexOf(' ') + 1);
                    Cell cell1 = list.get((x1 - 1) * column + y1 - 1);
                    Cell cell2 = list.get((x2 - 1) * column + y2 - 1);
                    //Transmitter transmitter= new Transmitter(cell1,cell2);
                    //transmitters.add(transmitter);
                    if (sssss.equals("D")) {
                        DeadlySnake d = new DeadlySnake(cell1, cell2);
                        cell1.setDeadlySnake(d); //اضافه
                        transmitters.add(d);
                    }
                    if (sssss.equals("E")) {
                        Earthworm e = new Earthworm(cell1, cell2);
                        cell1.setEarthworm(e); //اضافه
                        transmitters.add(e);
                    }
                    if (sssss.equals("M")) {
                        MagicSnake m = new MagicSnake(cell1, cell2);
                        cell1.setMagicSnake(m); //اضافه
                        transmitters.add(m);
                    }
                    if (sssss.equals("T")) {
                        Transmitter transmitter = new Transmitter(cell1, cell2);
                        cell1.setTransmitter(transmitter); //اضافه
                        transmitters.add(transmitter);
                    }
                }
                if (a == 81) {
                    String o = s.substring(8);
                    tedadjayeze = Integer.parseInt(o.substring(0, o.indexOf(' ')));
                }
                if (a > 81 && a < 82+tedadjayeze) {
                    String t1 = s.substring(0, s.indexOf(' '));
                    int x1 = Integer.parseInt(t1);
                    String ss = s.substring(s.indexOf(' ') + 1);
                    String t2 = ss.substring(0, ss.indexOf(' '));
                    int y1 = Integer.parseInt(t2);
                    String sss = ss.substring(ss.indexOf(' ') + 1);
                    String t3 = sss.substring(0, sss.indexOf(' '));
                    int point1 = Integer.parseInt(t3);
                    String ssss = sss.substring(sss.indexOf(' ') + 1);
                    String t4 = ssss.substring(0, ssss.indexOf(' '));
                    int chance = Integer.parseInt(t4);
                    String sssss = ssss.substring(ssss.indexOf(' ') + 1);
                    int dicenumb = Integer.parseInt(sssss);
                    if (x1!=0 && y1!=0) {
                        list.get((x1 - 1) * column + y1 - 1).setPrize(new Prize(list.get((x1 - 1) * column + y1 - 1), point1, chance, dicenumb));
                    }
                }
                if (a > 82+tedadjayeze && a < 100+tedadjayeze) {
                    if (a == 83+tedadjayeze) {
                        name1 = s;
                    }
                    if (a == 84+tedadjayeze) {
                        score1 = Integer.parseInt(s);
                    }
                    if (a == 85+tedadjayeze) {
                        id1 = Integer.parseInt(s);
                    }
                    if (a == 86+tedadjayeze) {
                        if (s.equals("true")) {
                            ready1 = true;
                        }
                        if (s.equals("false")) {
                            ready1 = false;
                        }
                    }
                    if (a == 87+tedadjayeze) {
                        if (s.equals("true")) {
                            tas_andakhte1 = true;
                        }
                        if (s.equals("false")) {
                            tas_andakhte1 = false;
                        }
                    }
                    if (a == 88+tedadjayeze) {
                        tas1 = Integer.parseInt(s);
                    }
                    if (a == 89+tedadjayeze) {
                        c1 = Integer.parseInt(String.valueOf(s.charAt(0)));
                        c2 = Integer.parseInt(String.valueOf(s.charAt(2)));
                        c3 = Integer.parseInt(String.valueOf(s.charAt(4)));
                        c4 = Integer.parseInt(String.valueOf(s.charAt(6)));
                        c5 = Integer.parseInt(String.valueOf(s.charAt(8)));
                        c6 = Integer.parseInt(String.valueOf(s.charAt(10)));
                    }
                    if (a == 90+tedadjayeze){
                        bp1_isDead= s.equals("true");
                    }
                    if (a == 91+tedadjayeze){
                        bp1_isBombing= s.equals("true");
                    }
                    if (a == 92+tedadjayeze){
                        hp1_isDead= s.equals("true");
                    }
                    if (a == 93+tedadjayeze){
                        hp1_isHealing= s.equals("true");
                    }
                    if (a == 94+tedadjayeze){
                        sp1_isDead= s.equals("true");
                    }
                    if (a == 95+tedadjayeze){
                        sp1_isSniping= s.equals("true");
                    }
                    if (a == 96+tedadjayeze){
                        tp1_isDead= s.equals("true");
                    }
                    if (a == 97+tedadjayeze){
                        tp1_isStealing= s.equals("true");
                    }
                    if (a == 98+tedadjayeze) {
                        if (s.equals("BomberPiece")) {
                            mohre1 = true;
                            bp1 = true;
                        }
                        if (s.equals("HealerPiece")) {
                            mohre1 = true;
                            hp1 = true;
                        }
                        if (s.equals("SniperPiece")) {
                            mohre1 = true;
                            sp1 = true;
                        }
                        if (s.equals("ThiefPiece")) {
                            mohre1 = true;
                            tp1 = true;
                        }
                    }
                    if (a == 99+tedadjayeze){
                        if (s.equals("null")){jayeze_dare1=false;}
                        else {
                            String t1 = s.substring(0, s.indexOf(' '));
                            point_1 = Integer.parseInt(t1);
                            String ss = s.substring(s.indexOf(' ') + 1);
                            String t2 = ss.substring(0, ss.indexOf(' '));
                            chance1 = Integer.parseInt(t2);
                            String sss = ss.substring(ss.indexOf(' ') + 1);
                            dice_number1 = Integer.parseInt(sss);
                        }
                    }
                }
                if (a > 100+tedadjayeze && a < 118+tedadjayeze) {
                    if (a == 101+tedadjayeze) {
                        name2 = s;
                    }
                    if (a == 102+tedadjayeze) {
                        score2 = Integer.parseInt(s);
                    }
                    if (a == 103+tedadjayeze) {
                        id2 = Integer.parseInt(s);
                    }
                    if (a == 104+tedadjayeze) {
                        if (s.equals("true")) {
                            ready2 = true;
                        }
                        if (s.equals("false")) {
                            ready2 = false;
                        }
                    }
                    if (a == 105+tedadjayeze) {
                        if (s.equals("true")) {
                            tas_andakhte2 = true;
                        }
                        if (s.equals("false")) {
                            tas_andakhte2 = false;
                        }
                    }
                    if (a == 106+tedadjayeze) {
                        tas2 = Integer.parseInt(s);
                    }
                    if (a == 107+tedadjayeze) {
                        ch1 = Integer.parseInt(String.valueOf(s.charAt(0)));
                        ch2 = Integer.parseInt(String.valueOf(s.charAt(2)));
                        ch3 = Integer.parseInt(String.valueOf(s.charAt(4)));
                        ch4 = Integer.parseInt(String.valueOf(s.charAt(6)));
                        ch5 = Integer.parseInt(String.valueOf(s.charAt(8)));
                        ch6 = Integer.parseInt(String.valueOf(s.charAt(10)));
                    }
                    if (a == 108+tedadjayeze){
                        bp2_isDead= s.equals("true");
                    }
                    if (a == 109+tedadjayeze){
                        bp2_isBombing= s.equals("true");
                    }
                    if (a == 110+tedadjayeze){
                        hp2_isDead= s.equals("true");
                    }
                    if (a == 111+tedadjayeze){
                        hp2_isHealing= s.equals("true");
                    }
                    if (a == 112+tedadjayeze){
                        sp2_isDead= s.equals("true");
                    }
                    if (a == 113+tedadjayeze){
                        sp2_isSniping= s.equals("true");
                    }
                    if (a == 114+tedadjayeze){
                        tp2_isDead= s.equals("true");
                    }
                    if (a == 115+tedadjayeze){
                        tp2_isStealing= s.equals("true");
                    }
                    if (a == 116+tedadjayeze) {
                        if (s.equals("BomberPiece")) {
                            mohre2 = true;
                            bp2 = true;
                        }
                        if (s.equals("HealerPiece")) {
                            mohre2 = true;
                            hp2 = true;
                        }
                        if (s.equals("SniperPiece")) {
                            mohre2 = true;
                            sp2 = true;
                        }
                        if (s.equals("ThiefPiece")) {
                            mohre2 = true;
                            tp2 = true;
                        }
                    }
                    if (a == 117+tedadjayeze){
                        if (s.equals("null")){jayeze_dare2=false;}
                        else {
                            String t1 = s.substring(0, s.indexOf(' '));
                            point_2 = Integer.parseInt(t1);
                            String ss = s.substring(s.indexOf(' ') + 1);
                            String t2 = ss.substring(0, ss.indexOf(' '));
                            chance2 = Integer.parseInt(t2);
                            String sss = ss.substring(ss.indexOf(' ') + 1);
                            dice_number2 = Integer.parseInt(sss);
                        }
                    }
                }
                if (a == 119+tedadjayeze) {
                    turn = Integer.parseInt(s);
                }
                a = a + 1;
            }
            scanner.close();

            for (Cell c : list) {
                for (Transmitter t : transmitters) {
                    if (c.getX() == t.getFirstCell().getX() && c.getY() == t.getFirstCell().getY()) {
                        c.setTransmitter(t);
                    }
                }
                List<Cell> ad = new ArrayList<>();
                for (int i = 0; i < list.size(); i++) {
                    Cell cell = list.get(i);
                    if (cell.getX() == c.getX() && cell.getY() == c.getY() + 1) {
                        ad.add(cell);
                    }
                    if (cell.getX() == c.getX() && cell.getY() == c.getY() - 1) {
                        ad.add(cell);
                    }
                    if (cell.getX() == c.getX() + 1 && cell.getY() == c.getY()) {
                        ad.add(cell);
                    }
                    if (cell.getX() == c.getX() - 1 && cell.getY() == c.getY()) {
                        ad.add(cell);
                    }
                }
                c.getAdjacentCells().addAll(ad);
                List<Cell> adjopencell = c.getAdjacentCells();
                List<Cell> ado = new ArrayList<>();
                for (Cell cell1 : c.getAdjacentCells()) {
                    for (Wall w : walls) {
                        if ((w.getCell1().equals(c) && w.getCell2().equals(cell1)) || (w.getCell1().equals(cell1) && w.getCell2().equals(c))) {
                            ado.add(cell1);
                        }
                    }
                }
                adjopencell.removeAll(ado);
                c.getAdjacentOpenCells().addAll(adjopencell);
            }
            board.setCells(list);
            board.setStartingCells(map);
            board.setTransmitters(transmitters);
            board.setWalls(walls);
            // ساخت برد

            //ساخت پلیر1
            Player player1= new Player(name1,score1,id1,1);
            player1.setScore(score1);
            player1.setReady(ready1);
            player1.setDicePlayedThisTurn(tas_andakhte1);
            player1.setMoveLeft(tas1);
            if (mohre1) {
                if (bp1) {
                    player1.setSelectedPiece(player1.getBomberPiece());
                }
                if (hp1) {
                    player1.setSelectedPiece(player1.getHealerPiece());
                }
                if (sp1) {
                    player1.setSelectedPiece(player1.getSniperPiece());
                }
                if (tp1) {
                    player1.setSelectedPiece(player1.getThiefPiece());
                }
            }
            player1.getBomberPiece().setDead(bp1_isDead);
            player1.getBomberPiece().setBombing(bp1_isBombing);
            player1.getHealerPiece().setDead(hp1_isDead);
            player1.getHealerPiece().setHealing(hp1_isHealing);
            player1.getSniperPiece().setDead(sp1_isDead);
            player1.getSniperPiece().setSniping(sp1_isSniping);
            player1.getThiefPiece().setDead(tp1_isDead);
            player1.getThiefPiece().setStealing(tp1_isStealing);
            if (jayeze_dare1){
                player1.getThiefPiece().setPrize(new Prize(player1.getThiefPiece(),point_1,chance1,dice_number1));
            }
            //ساخت پلیر1

            //ساخت پلیر2
            Player player2= new Player(name2,score2,id2,2);
            player2.setScore(score2);
            player2.setReady(ready2);
            player2.setDicePlayedThisTurn(tas_andakhte2);
            player2.setMoveLeft(tas2);
            if (mohre2) {
                if (bp2) {
                    player2.setSelectedPiece(player2.getBomberPiece());
                }
                if (hp2) {
                    player2.setSelectedPiece(player2.getHealerPiece());
                }
                if (sp2) {
                    player2.setSelectedPiece(player2.getSniperPiece());
                }
                if (tp2) {
                    player2.setSelectedPiece(player2.getThiefPiece());
                }
            }
            player2.getBomberPiece().setDead(bp2_isDead);
            player2.getBomberPiece().setBombing(bp2_isBombing);
            player2.getHealerPiece().setDead(hp2_isDead);
            player2.getHealerPiece().setHealing(hp2_isHealing);
            player2.getSniperPiece().setDead(sp2_isDead);
            player2.getSniperPiece().setSniping(sp2_isSniping);
            player2.getThiefPiece().setDead(tp2_isDead);
            player2.getThiefPiece().setStealing(tp2_isStealing);
            if (jayeze_dare2){
                player2.getThiefPiece().setPrize(new Prize(player2.getThiefPiece(),point_2,chance2,dice_number2));
            }
            //ساخت پلیر2

            player1.setRival(player2);
            player2.setRival(player1);

            if (player1.isReady() && player2.isReady()) {
                for (Cell c : board.getStartingCells().keySet()) {
                    if (board.getStartingCells().get(c) == 10) {
                        c.setPiece(player1.getBomberPiece());
                        c.setBomberPiece(player1.getBomberPiece());
                        player1.getBomberPiece().setCurrentCell(c);
                    }
                    if (board.getStartingCells().get(c) == 11) {
                        c.setPiece(player1.getThiefPiece());
                        c.setThiefPiece(player1.getThiefPiece());
                        player1.getThiefPiece().setCurrentCell(c);
                    }
                    if (board.getStartingCells().get(c) == 12) {
                        c.setPiece(player1.getHealerPiece());
                        c.setHealerPiece(player1.getHealerPiece());
                        player1.getHealerPiece().setCurrentCell(c);
                    }
                    if (board.getStartingCells().get(c) == 13) {
                        c.setPiece(player1.getSniperPiece());
                        c.setSniperPiece(player1.getSniperPiece());
                        player1.getSniperPiece().setCurrentCell(c);
                    }
                    if (board.getStartingCells().get(c) == 20) {
                        c.setPiece(player2.getBomberPiece());
                        c.setBomberPiece(player2.getBomberPiece());
                        player2.getBomberPiece().setCurrentCell(c);
                    }
                    if (board.getStartingCells().get(c) == 21) {
                        c.setPiece(player2.getThiefPiece());
                        c.setThiefPiece(player2.getThiefPiece());
                        player2.getThiefPiece().setCurrentCell(c);
                    }
                    if (board.getStartingCells().get(c) == 22) {
                        c.setPiece(player2.getHealerPiece());
                        c.setHealerPiece(player2.getHealerPiece());
                        player2.getHealerPiece().setCurrentCell(c);
                    }
                    if (board.getStartingCells().get(c) == 23) {
                        c.setPiece(player2.getSniperPiece());
                        c.setSniperPiece(player2.getSniperPiece());
                        player2.getSniperPiece().setCurrentCell(c);
                    }
                }
            }
            GameState gs= new GameState(board,player1,player2);
            gs.setTurn(turn);
            return gs;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Give a number from graphic,( which is the playerNumber of a player
     * who right clicks "dice button".) you should return the dice detail of that player.
     * you can use method "getDetails" in class "Dice"(not necessary, but recommended )
     */
    public String getDiceDetail(int playerNumber) {
        return this.gameState.getPlayer(playerNumber).getDice().getDetails();
    }
}
