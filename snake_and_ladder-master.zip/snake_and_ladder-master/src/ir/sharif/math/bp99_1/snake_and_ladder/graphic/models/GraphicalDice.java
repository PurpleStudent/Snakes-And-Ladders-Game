package ir.sharif.math.bp99_1.snake_and_ladder.graphic.models;

import java.awt.*;

public class GraphicalDice extends GraphicalModel {
    public GraphicalDice() {
    }

    @Override
    public void paint(Graphics2D graphics2D) {
    }
}
