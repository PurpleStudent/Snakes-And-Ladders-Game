package ir.sharif.math.bp99_1.snake_and_ladder.model.transmitters;

import ir.sharif.math.bp99_1.snake_and_ladder.model.Cell;
import ir.sharif.math.bp99_1.snake_and_ladder.model.Color;
import ir.sharif.math.bp99_1.snake_and_ladder.model.pieces.Piece;

public class MagicSnake extends Transmitter {
    public MagicSnake(Cell firstCell, Cell lastCell) {
        super(firstCell, lastCell);
    }

    public void transmit(Piece piece) {
        piece.getPlayer().setScore(piece.getPlayer().getScore()+3);
        if ((piece.getColor().equals(this.lastCell.getColor()) || this.lastCell.getColor().equals(Color.WHITE)) && this.lastCell.getPiece()==null){
            piece.moveTo(lastCell);
        }
        if (!piece.isDead()){
            if (piece.getColor().equals(Color.RED)){piece.getPlayer().getBomberPiece().setBombing(true);}
            if (piece.getColor().equals(Color.YELLOW)){piece.getPlayer().getSniperPiece().setSniping(true);}
            if (piece.getColor().equals(Color.GREEN)){piece.getPlayer().getHealerPiece().setHealing(true);}
            //if (piece.getColor().equals(Color.BLUE)){}
        }
    }
}
