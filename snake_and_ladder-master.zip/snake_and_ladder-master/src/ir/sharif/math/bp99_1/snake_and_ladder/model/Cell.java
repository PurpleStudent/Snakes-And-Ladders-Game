package ir.sharif.math.bp99_1.snake_and_ladder.model;

import ir.sharif.math.bp99_1.snake_and_ladder.model.pieces.*;
import ir.sharif.math.bp99_1.snake_and_ladder.model.prizes.Prize;
import ir.sharif.math.bp99_1.snake_and_ladder.model.transmitters.DeadlySnake;
import ir.sharif.math.bp99_1.snake_and_ladder.model.transmitters.Earthworm;
import ir.sharif.math.bp99_1.snake_and_ladder.model.transmitters.MagicSnake;
import ir.sharif.math.bp99_1.snake_and_ladder.model.transmitters.Transmitter;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Cell {
    private Color color; //فاینال رو برداشتم
    private final int x, y;

    private Transmitter transmitter;
    private DeadlySnake deadlySnake; //اضافه
    private Earthworm earthworm; //اضافه
    private MagicSnake magicSnake; //اضافه

    private Prize prize;

    private Piece piece;
    private BomberPiece bomberPiece; //اضافه
    private HealerPiece healerPiece; //اضافه
    private SniperPiece sniperPiece; //اضافه
    private ThiefPiece thiefPiece; //اضافه

    private final List<Cell> adjacentOpenCells;
    private final List<Cell> adjacentCells;

    public Cell(Color color, int x, int y) {
        this.color = color;
        this.x = x;
        this.y = y;

        this.transmitter = null;
        this.deadlySnake = null; //اضافه
        this.earthworm = null; //اضافه
        this.magicSnake = null; //اضافه

        this.prize = null;

        this.piece = null;
        this.bomberPiece = null; //اضافه
        this.healerPiece = null; //اضافه
        this.sniperPiece = null; //اضافه
        this.thiefPiece = null; //اضافه

        this.adjacentOpenCells = new ArrayList<>();
        this.adjacentCells = new ArrayList<>();
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public Color getColor() {
        return color;
    }
    public void setColor(Color color){this.color = color;}

    public List<Cell> getAdjacentCells() { //بدون ورودی
        return adjacentCells;
    }

    public List<Cell> getAdjacentOpenCells() { //بدون ورودی
        return adjacentOpenCells;
    }

    public Piece getPiece() {
        return piece;
    }

    public Prize getPrize() {
        return prize;
    }

    public Transmitter getTransmitter() {
        return transmitter;
    }

    public void setPiece(Piece piece) {
        this.piece = piece;
    }

    public void setPrize(Prize prize) {
        this.prize = prize;
    }

    public void setTransmitter(Transmitter transmitter) {
        this.transmitter = transmitter;
    }

    public DeadlySnake getDeadlySnake(){return deadlySnake;}
    public void setDeadlySnake(DeadlySnake deadlySnake){this.deadlySnake = deadlySnake;}

    public Earthworm getEarthworm(){return earthworm;}
    public void setEarthworm(Earthworm earthworm){this.earthworm = earthworm;}

    public MagicSnake getMagicSnake(){return magicSnake;}
    public void setMagicSnake(MagicSnake magicSnake){this.magicSnake = magicSnake;}

    public BomberPiece getBomberPiece(){return bomberPiece;}
    public void setBomberPiece(BomberPiece bomberPiece){this.bomberPiece=bomberPiece;}

    public HealerPiece getHealerPiece(){return healerPiece;}
    public void setHealerPiece(HealerPiece healerPiece){this.healerPiece=healerPiece;}

    public SniperPiece getSniperPiece(){return sniperPiece;}
    public void setSniperPiece(SniperPiece sniperPiece){this.sniperPiece=sniperPiece;}

    public ThiefPiece getThiefPiece(){return thiefPiece;}
    public void setThiefPiece(ThiefPiece thiefPiece){this.thiefPiece=thiefPiece;}

    /**
     * @return true if piece can enter this cell, else return false
     */
    public boolean canEnter(Piece piece) {
        boolean color;
        boolean anotherpiece;
        color= piece.getColor().equals(this.color) || this.getColor().equals(Color.WHITE);
        anotherpiece= this.piece == null;
        return color && anotherpiece;
    }


    /**
     * DO NOT CHANGE FOLLOWING METHODS.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Cell cell = (Cell) o;
        return x == cell.x && y == cell.y;
    }

    @Override
    public int hashCode() {
        return Objects.hash(x, y);
    }
}
