package ir.sharif.math.bp99_1.snake_and_ladder.model;

import ir.sharif.math.bp99_1.snake_and_ladder.logic.ModelLoader;
import ir.sharif.math.bp99_1.snake_and_ladder.model.transmitters.Transmitter;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class Board {
    private List<Cell> cells; //final
    private List<Transmitter> transmitters; //final
    private List<Wall> walls; //final
    private Map<Cell, Integer> startingCells; //final

    public Board() {
        cells = new LinkedList<>();
        transmitters = new LinkedList<>();
        walls = new LinkedList<>();
        startingCells = new HashMap<>();
    }

    public List<Cell> getCells() {
        return cells;
    }
    public void setCells(List<Cell> cells){this.cells=cells;}

    public List<Wall> getWalls() {
        return walls;
    }
    public void setWalls(List<Wall> walls){this.walls=walls;}

    public Map<Cell, Integer> getStartingCells() {
        return startingCells;
    }
    public void setStartingCells(Map<Cell,Integer> startingCells){this.startingCells=startingCells;}

    public List<Transmitter> getTransmitters() {
        return transmitters;
    }
    public void setTransmitters(List<Transmitter> transmitters){this.transmitters=transmitters;}

    /**
     * give x,y , return a cell with that coordinates
     * return null if not exist.
     */
    public Cell getCell(int x, int y) {
        Cell cell= null;
        for (Cell c: this.cells) {
            if (c.getX()==x && c.getY()==y){
                cell= c;
            }
        }
        return cell;
    }
}
