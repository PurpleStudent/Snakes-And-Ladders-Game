package ir.sharif.math.bp99_1.snake_and_ladder.logic;

import ir.sharif.math.bp99_1.snake_and_ladder.model.Board;
import ir.sharif.math.bp99_1.snake_and_ladder.model.Cell;
import ir.sharif.math.bp99_1.snake_and_ladder.model.Color;

import java.util.*;


public class BoardBuilder {
    String str;
    int satr;
    int sotoon;
    public BoardBuilder(String src, int a, int b) {
        this.str=src;
        this.satr=a;
        this.sotoon=b;
    }
    /*public List<Cell> CELLS(){
        String string= this.str;
        List<Cell> list= new ArrayList<>();
        String s1="";
        for (int i = 1; i < this.sotoon+1; i++) {    //+1
            Cell cell;
            if (i!=this.sotoon) {s1=string.substring(0,string.indexOf(' '));}
            if (i==this.sotoon) {s1=string.substring(0);}
            if (s1.equals("WHITE")){
                cell= new Cell(Color.WHITE,this.satr,i);
                list.add(cell);
            }
            if (s1.equals("BLACK")){
                cell= new Cell(Color.BLACK,this.satr,i);
                list.add(cell);
            }
            if (s1.equals("BLUE")){
                cell= new Cell(Color.BLUE,this.satr,i);
                list.add(cell);
            }
            if (s1.equals("RED")){
                cell= new Cell(Color.RED,this.satr,i);
                list.add(cell);
            }
            if (s1.equals("GREEN")){
                cell= new Cell(Color.GREEN,this.satr,i);
                list.add(cell);
            }
            if (s1.equals("YELLOW")){
                cell= new Cell(Color.YELLOW,this.satr,i);
                list.add(cell);
            }
            //list.add(cell);
            string=string.substring(string.indexOf(' ')+1);
        }
        return list;
    }*/
    /**
     * give you a string in constructor.
     * <p>
     * you should read the string and create a board according to it.
     */
    public Board build() {


        return null;
    }


}
