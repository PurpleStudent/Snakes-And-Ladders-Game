package ir.sharif.math.bp99_1.snake_and_ladder.model.transmitters;

import ir.sharif.math.bp99_1.snake_and_ladder.model.Board;
import ir.sharif.math.bp99_1.snake_and_ladder.model.Cell;
import ir.sharif.math.bp99_1.snake_and_ladder.model.Color;
import ir.sharif.math.bp99_1.snake_and_ladder.model.Player;
import ir.sharif.math.bp99_1.snake_and_ladder.model.pieces.Piece;

import java.util.Random;

public class Earthworm extends Transmitter {
    public Earthworm(Cell firstCell, Cell lastCell) {
        super(firstCell, lastCell);
    }

    public void differenttransmit(Piece piece,Board board) {
        piece.getPlayer().setScore(piece.getPlayer().getScore()-3);
        Random r= new Random();
        int x= r.nextInt(7)+1; //تعمیم بده
        int y= r.nextInt(16)+1; //تعمیم بده
        if ((piece.getColor().equals(board.getCell(x,y).getColor()) || board.getCell(x,y).getColor().equals(Color.WHITE)) && board.getCell(x,y).getPiece()==null){
            piece.moveTo(board.getCell(x,y));
        }
    }
}
