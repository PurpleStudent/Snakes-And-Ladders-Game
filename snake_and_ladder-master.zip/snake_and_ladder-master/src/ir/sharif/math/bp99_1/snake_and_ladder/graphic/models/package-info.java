/**
 * this package for building a graphical models
 * models that contains the all attribute for painting objects
 * this models have <code>public void paint(Graphics g)</code> method
 */
package ir.sharif.math.bp99_1.snake_and_ladder.graphic.models;