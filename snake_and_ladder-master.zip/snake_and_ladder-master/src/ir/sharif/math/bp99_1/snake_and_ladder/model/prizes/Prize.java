package ir.sharif.math.bp99_1.snake_and_ladder.model.prizes;

import ir.sharif.math.bp99_1.snake_and_ladder.model.Cell;
import ir.sharif.math.bp99_1.snake_and_ladder.model.pieces.Piece;
import ir.sharif.math.bp99_1.snake_and_ladder.model.pieces.ThiefPiece;

public class Prize {
    private Cell cell; // فاینال
    private final int point;
    private final int chance, diceNumber;
    private ThiefPiece thiefPiece; // اضافه


    public Prize(Cell cell, int point, int chance, int diceNumber) {
        this.cell = cell;
        this.point = point;
        this.chance = chance;
        this.diceNumber = diceNumber;
        this.thiefPiece=null; // اضافه
    }

    public Prize(ThiefPiece thiefPiece,int point,int chance,int diceNumber){ //اضافه
        this.cell=null;
        this.point=point;
        this.chance=chance;
        this.diceNumber=diceNumber;
        this.thiefPiece=thiefPiece;
    }

    public int getPoint() {
        return point;
    }

    public Cell getCell() {
        return cell;
    }
    public void setCell(Cell cell){this.cell=cell;}

    public int getChance() {
        return chance;
    }

    public int getDiceNumber() {
        return diceNumber;
    }

    public ThiefPiece getThiefPiece(){return thiefPiece;}
    public void setThiefPiece(ThiefPiece thiefPiece){this.thiefPiece=thiefPiece;}


    /**
     * apply the prize.
     * you can use method "usePrize" in class "Player" (not necessary, but recommended)
     */
    public void using(Piece piece) {
        piece.getPlayer().usePrize(this);
    }

}
