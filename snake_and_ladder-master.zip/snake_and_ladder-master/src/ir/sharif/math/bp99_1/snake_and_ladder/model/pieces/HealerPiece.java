package ir.sharif.math.bp99_1.snake_and_ladder.model.pieces;

import ir.sharif.math.bp99_1.snake_and_ladder.model.Board;
import ir.sharif.math.bp99_1.snake_and_ladder.model.Cell;
import ir.sharif.math.bp99_1.snake_and_ladder.model.Color;
import ir.sharif.math.bp99_1.snake_and_ladder.model.Player;

public class HealerPiece extends Piece {
    private boolean Healing;

    public HealerPiece(Player player, Color color) {
        super(player, color);
        this.Healing = false;
    }

    public boolean isHealing() {
        return Healing;
    }

    public void setHealing(boolean healing) {
        Healing = healing;
    }

    public void KillThePiece() {
        super.KillThePiece();
        this.setHealing(false);
    }

    public void HealThePiece(Board board) {
        if (this.isHealing()) {
            if (board.getCell(this.getCurrentCell().getX() + 1, this.getCurrentCell().getY()) != null) {
                Cell c1 = board.getCell(this.getCurrentCell().getX() + 1, this.getCurrentCell().getY());
                if (c1.getPiece() != null) {
                    if (c1.getPiece().getPlayer().getPieces().contains(this)) {
                        if (c1.getPiece().isDead) {
                            c1.getPiece().setDead(false);
                            if (c1.getPiece().getColor().equals(Color.BLUE)){this.getPlayer().getThiefPiece().setStealing(true);}
                            this.setHealing(false);
                        }
                    }
                }
            }
            if (board.getCell(this.getCurrentCell().getX() - 1, this.getCurrentCell().getY()) != null) {
                Cell c2 = board.getCell(this.getCurrentCell().getX() - 1, this.getCurrentCell().getY());
                if (c2.getPiece() != null) {
                    if (c2.getPiece().getPlayer().getPieces().contains(this)) {
                        if (c2.getPiece().isDead) {
                            c2.getPiece().setDead(false);
                            if (c2.getPiece().getColor().equals(Color.BLUE)){this.getPlayer().getThiefPiece().setStealing(true);}
                            this.setHealing(false);
                        }
                    }
                }
            }
            if (board.getCell(this.getCurrentCell().getX(), this.getCurrentCell().getY() + 1) != null) {
                Cell c3 = board.getCell(this.getCurrentCell().getX(), this.getCurrentCell().getY() + 1);
                if (c3.getPiece() != null) {
                    if (c3.getPiece().getPlayer().getPieces().contains(this)) {
                        if (c3.getPiece().isDead) {
                            c3.getPiece().setDead(false);
                            if (c3.getPiece().getColor().equals(Color.BLUE)){this.getPlayer().getThiefPiece().setStealing(true);}
                            this.setHealing(false);
                        }
                    }
                }
            }
            if (board.getCell(this.getCurrentCell().getX(), this.getCurrentCell().getY() - 1) != null) {
                Cell c4 = board.getCell(this.getCurrentCell().getX(), this.getCurrentCell().getY() - 1);
                if (c4.getPiece() != null) {
                    if (c4.getPiece().getPlayer().getPieces().contains(this)) {
                        if (c4.getPiece().isDead) {
                            c4.getPiece().setDead(false);
                            if (c4.getPiece().getColor().equals(Color.BLUE)){this.getPlayer().getThiefPiece().setStealing(true);}
                            this.setHealing(false);
                        }
                    }
                }
            }
        }
    }

    public void moveTo(Cell destination){
        super.moveTo(destination);
        this.getCurrentCell().setHealerPiece(null);
        destination.setHealerPiece(this);
    }
}
