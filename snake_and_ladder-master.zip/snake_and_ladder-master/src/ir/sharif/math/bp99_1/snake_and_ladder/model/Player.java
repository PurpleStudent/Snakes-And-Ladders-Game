package ir.sharif.math.bp99_1.snake_and_ladder.model;

import ir.sharif.math.bp99_1.snake_and_ladder.model.pieces.*;
import ir.sharif.math.bp99_1.snake_and_ladder.model.prizes.Prize;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

public class Player {
    private final String name;
    private int score;
    private final List<Piece> pieces;

    private BomberPiece bomberPiece; //ezafe
    private HealerPiece healerPiece; //ezafe
    private SniperPiece sniperPiece; //ezafe
    private ThiefPiece thiefPiece; //ezafe

    private final Dice dice;
    private Player rival;
    private final int id;
    private int playerNumber;
    private boolean isReady;
    private boolean dicePlayedThisTurn;
    private int moveLeft;
    private Piece selectedPiece;

    public Player(String name, int score, int id, int playerNumber) {
        this.name = name;
        this.score = score;
        this.id = id;
        this.playerNumber = playerNumber;
        this.dice = new Dice();
        this.pieces = new ArrayList<>();

        this.bomberPiece = new BomberPiece(this,Color.RED);
        this.thiefPiece = new ThiefPiece(this,Color.BLUE);
        this.healerPiece = new HealerPiece(this,Color.GREEN);
        this.sniperPiece = new SniperPiece(this,Color.YELLOW);

        this.pieces.add(bomberPiece);
        this.pieces.add(thiefPiece);
        this.pieces.add(healerPiece);
        this.pieces.add(sniperPiece);

        this.moveLeft = 0;
        this.selectedPiece = null;
        this.dicePlayedThisTurn = false;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Dice getDice() {
        return dice;
    }

    public int getScore() {
        return score;
    }

    public List<Piece> getPieces() {
        return pieces;
    }

    public int getPlayerNumber() {
        return playerNumber;
    }

    public void setPlayerNumber(int playerNumber) {
        this.playerNumber = playerNumber;
    }

    public Player getRival() {
        return rival;
    }

    public int getMoveLeft() {
        return moveLeft;
    }

    public Piece getSelectedPiece() {
        return selectedPiece;
    }

    public boolean isDicePlayedThisTurn() {
        return dicePlayedThisTurn;
    }

    public void setDicePlayedThisTurn(boolean dicePlayedThisTurn) {
        this.dicePlayedThisTurn = dicePlayedThisTurn;
    }

    public void setSelectedPiece(Piece selectedPiece) {
        this.selectedPiece = selectedPiece;
    }

    public void setMoveLeft(int moveLeft) {
        this.moveLeft = moveLeft;
    }

    public void setRival(Player rival) {
        this.rival = rival;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public void applyOnScore(int score) {
        this.score += score;
    }

    public boolean isReady() {
        return isReady;
    }

    public void setReady(boolean ready) {
        isReady = ready;
    }

    public BomberPiece getBomberPiece() {
        return bomberPiece;
    }
    public void setBomberPiece(BomberPiece bomberPiece){this.bomberPiece=bomberPiece;}

    public HealerPiece getHealerPiece() {
        return healerPiece;
    }
    public void setHealerPiece(HealerPiece healerPiece){this.healerPiece=healerPiece;}

    public SniperPiece getSniperPiece() {
        return sniperPiece;
    }
    public void setSniperPiece(SniperPiece sniperPiece){this.sniperPiece=sniperPiece;}

    public ThiefPiece getThiefPiece() {
        return thiefPiece;
    }
    public void setThiefPiece(ThiefPiece thiefPiece){this.thiefPiece=thiefPiece;}

    /**
     * @param prize according to input prize , apply necessary changes to score and dice chance
     *              <p>
     *              you can use method "addChance" in class "Dice"(not necessary, but recommended)
     */
    public void usePrize(Prize prize) {
        this.setScore(this.getScore()+prize.getPoint());
        this.getDice().addChance(prize.getDiceNumber(),prize.getChance());
    }


    /**
     * check if any of player pieces can move to another cell.
     *
     * @return true if at least 1 piece has a move , else return false
     * <p>
     * you can use method "isValidMove" in class "Piece"(not necessary, but recommended)
     */
    public boolean hasMove(Board board, int diceNumber) {
        LinkedList<Boolean> move= new LinkedList<>();
        for (int i = 0; i < 4; i++) {
            Cell c= this.pieces.get(i).getCurrentCell();
            Cell destination1= board.getCell(c.getX()+diceNumber,c.getY());
            Cell destination2= board.getCell(c.getX()-diceNumber,c.getY());
            Cell destination3= board.getCell(c.getX(),c.getY()+diceNumber);
            Cell destination4= board.getCell(c.getX(),c.getY()-diceNumber);

            boolean validmove1;
            if (destination1==null){validmove1=false;}
            else {validmove1=this.getPieces().get(i).isValidMove(destination1,diceNumber,board) && !this.getPieces().get(i).isDead();}
            move.add(validmove1);

            boolean validmove2;
            if (destination2==null){validmove2=false;}
            else {validmove2=this.getPieces().get(i).isValidMove(destination2,diceNumber,board) && !this.getPieces().get(i).isDead();}
            move.add(validmove2);

            boolean validmove3;
            if (destination3==null){validmove3=false;}
            else {validmove3=this.getPieces().get(i).isValidMove(destination3,diceNumber,board) && !this.getPieces().get(i).isDead();}
            move.add(validmove3);

            boolean validmove4;
            if (destination4==null){validmove4=false;}
            else {validmove4=this.getPieces().get(i).isValidMove(destination4,diceNumber,board) && !this.getPieces().get(i).isDead();}
            move.add(validmove4);
        }
        return move.contains(true);
    }


    /**
     * Deselect selectedPiece and make some changes in this class fields.
     */
    // **
    public void endTurn() {
        //this.setSelectedPiece(null);
        //this.setDicePlayedThisTurn(false);
    }


    /**
     * DO NOT CHANGE FOLLOWING METHODS.
     */

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Player player = (Player) o;
        return Objects.equals(name, player.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }
}

