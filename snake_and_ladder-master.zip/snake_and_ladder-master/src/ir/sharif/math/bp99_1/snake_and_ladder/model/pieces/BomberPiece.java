package ir.sharif.math.bp99_1.snake_and_ladder.model.pieces;

import ir.sharif.math.bp99_1.snake_and_ladder.model.Board;
import ir.sharif.math.bp99_1.snake_and_ladder.model.Cell;
import ir.sharif.math.bp99_1.snake_and_ladder.model.Color;
import ir.sharif.math.bp99_1.snake_and_ladder.model.Player;

public class BomberPiece extends Piece {
    private boolean Bombing;
    public BomberPiece(Player player, Color color) {
        super(player, color);
        this.Bombing= false;
    }
    public boolean isBombing() {
        return Bombing;
    }
    public void setBombing(boolean bombing) {
        Bombing = bombing;
    }

    public void KillThePiece(){
        super.KillThePiece();
        this.setBombing(false);
    }

    public void DetonateTheBomb(Board board){
        if (board.getCell(this.currentCell.getX()+1,this.currentCell.getY())!=null){
            Cell c1=board.getCell(this.currentCell.getX()+1,this.currentCell.getY());
            c1.setPrize(null);
            if (c1.getPiece()!=null){
                if (!c1.getPiece().getColor().equals(Color.GREEN)){
                    c1.getPiece().KillThePiece();
                }
            }
        }
        if (board.getCell(this.currentCell.getX()-1,this.currentCell.getY())!=null){
            Cell c2=board.getCell(this.currentCell.getX()-1,this.currentCell.getY());
            c2.setPrize(null);
            if (c2.getPiece()!=null){
                if (!c2.getPiece().getColor().equals(Color.GREEN)){
                    c2.getPiece().KillThePiece();
                }
            }
        }
        if (board.getCell(this.currentCell.getX(),this.currentCell.getY()+1)!=null){
            Cell c3=board.getCell(this.currentCell.getX(),this.currentCell.getY()+1);
            c3.setPrize(null);
            if (c3.getPiece()!=null){
                if (!c3.getPiece().getColor().equals(Color.GREEN)){
                    c3.getPiece().KillThePiece();
                }
            }
        }
        if (board.getCell(this.currentCell.getX(),this.currentCell.getY()-1)!=null){
            Cell c4=board.getCell(this.currentCell.getX(),this.currentCell.getY()-1);
            c4.setPrize(null);
            if (c4.getPiece()!=null){
                if (!c4.getPiece().getColor().equals(Color.GREEN)){
                    c4.getPiece().KillThePiece();
                }
            }
        }
        if (board.getCell(this.currentCell.getX()-1,this.currentCell.getY()-1)!=null){
            Cell c5=board.getCell(this.currentCell.getX()-1,this.currentCell.getY()-1);
            c5.setPrize(null);
            if (c5.getPiece()!=null){
                if (!c5.getPiece().getColor().equals(Color.GREEN)){
                    c5.getPiece().KillThePiece();
                }
            }
        }
        if (board.getCell(this.currentCell.getX()-1,this.currentCell.getY()+1)!=null){
            Cell c6=board.getCell(this.currentCell.getX()-1,this.currentCell.getY()+1);
            c6.setPrize(null);
            if (c6.getPiece()!=null){
                if (!c6.getPiece().getColor().equals(Color.GREEN)){
                    c6.getPiece().KillThePiece();
                }
            }
        }
        if (board.getCell(this.currentCell.getX()+1,this.currentCell.getY()-1)!=null){
            Cell c7=board.getCell(this.currentCell.getX()+1,this.currentCell.getY()-1);
            c7.setPrize(null);
            if (c7.getPiece()!=null){
                if (!c7.getPiece().getColor().equals(Color.GREEN)){
                    c7.getPiece().KillThePiece();
                }
            }
        }
        if (board.getCell(this.currentCell.getX()+1,this.currentCell.getY()+1)!=null){
            Cell c8=board.getCell(this.currentCell.getX()+1,this.currentCell.getY()+1);
            c8.setPrize(null);
            if (c8.getPiece()!=null){
                if (!c8.getPiece().getColor().equals(Color.GREEN)){
                    c8.getPiece().KillThePiece();
                }
            }
        }
        if (board.getCell(this.currentCell.getX(),this.currentCell.getY())!=null){
            Cell c9=board.getCell(this.currentCell.getX(),this.currentCell.getY());
            c9.setPrize(null);
            if (c9.getPiece()!=null){
                if (!c9.getPiece().getColor().equals(Color.GREEN)){
                    c9.getPiece().KillThePiece(); //بمبر هم مرد
                }
            }
            c9.setColor(Color.BLACK);
        }
    }
    public void moveTo(Cell destination){
        super.moveTo(destination);
        this.getCurrentCell().setBomberPiece(null);
        destination.setBomberPiece(this);
    }
}
