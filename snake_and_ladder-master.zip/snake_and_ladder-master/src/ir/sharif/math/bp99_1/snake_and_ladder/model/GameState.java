package ir.sharif.math.bp99_1.snake_and_ladder.model;

import java.io.File;
import java.util.HashMap;

public class GameState {
    private final Board board;
    private final Player player1;
    private final Player player2;
    private int turn;
    private HashMap<Integer,Integer> map; //خودم اضافه کردم
    private File file; //خودم اضافه کردم

    public GameState(Board board, Player player1, Player player2) {
        this.board = board;
        this.player1 = player1;
        this.player2 = player2;
        turn = 0;
        this.map = new HashMap<>(); //خودم اضافه کردم
        this.file=null;
    }

    public Board getBoard() {
        return board;
    }

    public Player getPlayer1() {
        return player1;
    }

    public Player getPlayer2() {
        return player2;
    }

    public Player getPlayer(int i) {
        if (i == 1) return player1;
        else if (i == 2) return player2;
        else return null;
    }

    public boolean isStarted() {
        return turn != 0;
    }

    public int getTurn() {
        return turn;
    }
    public void setTurn(int turn){this.turn=turn;}

    public HashMap<Integer,Integer> getMap(){return map;} //اضافه
    public void setMap(HashMap<Integer,Integer>map){this.map=map;} //اضافه

    public File getFile(){return file;}
    public void setFile(File file){this.file=file;}


    /**
     * return null if game is not started.
     * else return a player who's turn is now.
     */
    public Player getCurrentPlayer() {
        Player p=null;
        if (this.turn==0){
            if (this.player1.isReady()){p=this.player1;}
            if (this.player2.isReady()){p=this.player2;}
        }
        if (this.getTurn()>0 && this.getTurn()%2==1){  //تغییر دادم
            p=this.player1;
        }
        if (this.getTurn()>0 && this.getTurn()%2==0){  //تغییر دادم
            p=this.player2;
        }
        return p;
    }


    /**
     * finish current player's turn and update some fields of this class;
     * you can use method "endTurn" in class "Player" (not necessary, but recommanded)
     */
    public void nextTurn() {
        //this.getCurrentPlayer().endTurn();
        this.getCurrentPlayer().setDicePlayedThisTurn(false);
        this.getCurrentPlayer().setSelectedPiece(null);
        turn=this.turn+1;
    }

    public int NumberOfPrizes(){
        int n=0;
        for (Cell c:this.board.getCells()) {
            if (c.getPrize()!=null){
                n=n+1;
            }
        }
        if (this.getPlayer1().getThiefPiece().getPrize()!=null){n=n+1;}
        if (this.getPlayer2().getThiefPiece().getPrize()!=null){n=n+1;}
        return n;
    }


    @Override
    public String toString() {
        return "GameState{" +
                "board=" + board +
                ", playerOne=" + player1 +
                ", playerTwo=" + player2 +
                ", turn=" + turn +
                '}';
    }
}
