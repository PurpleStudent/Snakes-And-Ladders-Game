package ir.sharif.math.bp99_1.snake_and_ladder.logic;

import ir.sharif.math.bp99_1.snake_and_ladder.model.*;
import ir.sharif.math.bp99_1.snake_and_ladder.model.pieces.Piece;
import ir.sharif.math.bp99_1.snake_and_ladder.model.prizes.Prize;
import ir.sharif.math.bp99_1.snake_and_ladder.model.transmitters.DeadlySnake;
import ir.sharif.math.bp99_1.snake_and_ladder.model.transmitters.Earthworm;
import ir.sharif.math.bp99_1.snake_and_ladder.model.transmitters.MagicSnake;
import ir.sharif.math.bp99_1.snake_and_ladder.model.transmitters.Transmitter;
import ir.sharif.math.bp99_1.snake_and_ladder.util.Config;

import java.io.*;
import java.util.*;

public class ModelLoader {
    private final File boardFile, playersDirectory, archiveFile;


    /**
     * DO NOT CHANGE ANYTHING IN CONSTRUCTOR.
     */
    public ModelLoader() {
        boardFile = Config.getConfig("mainConfig").getProperty(File.class, "board");
        playersDirectory = Config.getConfig("mainConfig").getProperty(File.class, "playersDirectory");
        archiveFile = Config.getConfig("mainConfig").getProperty(File.class, "archive");
        if (!playersDirectory.exists()) playersDirectory.mkdirs();
    }

    public File getBoardFile() {
        return boardFile;
    }
    public File getPlayersDirectory(){return playersDirectory;}
    public File getArchiveFile(){return archiveFile;}


    /**
     * read file "boardFile" and craete a Board
     * <p>
     * you can use "BoardBuilder" class for this purpose.
     * <p>
     * pay attention add your codes in "try".
     */
    public Board loadBord() {
        try {
            Scanner scanner = new Scanner(boardFile);
            int a=0;
            int row=0;
            int column=0;
            int tedadmohre=0;
            int tedaddivar=0;
            int tedadmar=0;
            int tedadjayeze=0;
            List<Cell> list= new LinkedList<>();
            Map<Cell,Integer> map= new HashMap<>();
            List<Wall> walls= new LinkedList<>();
            List<Transmitter> transmitters= new LinkedList<>();
            while (scanner.hasNext()){
                String s=scanner.nextLine();
                if (a==0){
                    String s1=s.substring(7);
                    row= Integer.parseInt(s1.substring(0,s1.indexOf(' ')));
                    String s2=s1.substring(s1.indexOf(' ')+1);
                    column= Integer.parseInt(s2.substring(0,s2.indexOf(' ')));
                }
                if (a>0 && a<row+1){
                    String string= s;
                    String s1="";
                    for (int i = 1; i < column+1; i++) {    //+1
                        Cell cell;
                        if (i!=column) {s1=string.substring(0,string.indexOf(' '));}
                        if (i==column) {s1=string.substring(0);}
                        if (s1.equals("WHITE")){
                            cell= new Cell(Color.WHITE,a,i);
                            list.add(cell);
                        }
                        if (s1.equals("BLACK")){
                            cell= new Cell(Color.BLACK,a,i);
                            list.add(cell);
                        }
                        if (s1.equals("BLUE")){
                            cell= new Cell(Color.BLUE,a,i);
                            list.add(cell);
                        }
                        if (s1.equals("RED")){
                            cell= new Cell(Color.RED,a,i);
                            list.add(cell);
                        }
                        if (s1.equals("GREEN")){
                            cell= new Cell(Color.GREEN,a,i);
                            list.add(cell);
                        }
                        if (s1.equals("YELLOW")){
                            cell= new Cell(Color.YELLOW,a,i);
                            list.add(cell);
                        }
                        string=string.substring(string.indexOf(' ')+1);
                    }
                }
                if (a==row+2){
                    String w1= s.substring(16);
                    tedadmohre=Integer.parseInt(w1.substring(0,w1.indexOf(' ')));
                }
                if (a > row+2 && a < row+3+tedadmohre) {
                    String s1= s.substring(0, s.indexOf(' '));
                    int x= Integer.parseInt(s1);
                    String ss= s.substring(s.indexOf(' ')+1);
                    String s2= ss.substring(0,ss.indexOf(' '));
                    int y= Integer.parseInt(s2);
                    String sss= ss.substring(ss.indexOf(' ')+1);
                    int pn= Integer.parseInt(sss);
                    Cell cell=list.get((x-1)*column+y-1);
                    map.put(cell,pn);
                }
                if (a==row+4+tedadmohre){
                    String e1= s.substring(7);
                    tedaddivar=Integer.parseInt(e1.substring(0,e1.indexOf(' ')));
                }
                if (a>row+4+tedadmohre && a<row+5+tedadmohre+tedaddivar){
                    String t1= s.substring(0, s.indexOf(' '));
                    int x1= Integer.parseInt(t1);
                    String ss= s.substring(s.indexOf(' ')+1);
                    String t2= ss.substring(0,ss.indexOf(' '));
                    int y1= Integer.parseInt(t2);
                    String sss= ss.substring(ss.indexOf(' ')+1);
                    String t3= sss.substring(0,sss.indexOf(' '));
                    int x2= Integer.parseInt(t3);
                    String ssss= sss.substring(sss.indexOf(' ')+1);
                    int y2= Integer.parseInt(ssss);
                    Cell cell1=list.get((x1-1)*column+y1-1);
                    Cell cell2=list.get((x2-1)*column+y2-1);
                    Wall wall= new Wall(cell1,cell2);
                    walls.add(wall);
                }
                if (a==row+6+tedadmohre+tedaddivar){
                    String u= s.substring(14);
                    tedadmar=Integer.parseInt(u.substring(0,u.indexOf(' ')));
                }
                if (a>row+6+tedadmohre+tedaddivar && a<row+7+tedadmohre+tedaddivar+tedadmar){
                    String t1= s.substring(0, s.indexOf(' '));
                    int x1= Integer.parseInt(t1);
                    String ss= s.substring(s.indexOf(' ')+1);
                    String t2= ss.substring(0,ss.indexOf(' '));
                    int y1= Integer.parseInt(t2);
                    String sss= ss.substring(ss.indexOf(' ')+1);
                    String t3= sss.substring(0,sss.indexOf(' '));
                    int x2= Integer.parseInt(t3);
                    String ssss= sss.substring(sss.indexOf(' ')+1);
                    String t4= ssss.substring(0,ssss.indexOf(' ')); //اضافه کردم
                    int y2= Integer.parseInt(t4); //تو پرانتز t4 گذاشتم
                    String sssss= ssss.substring(ssss.indexOf(' ')+1);
                    Cell cell1=list.get((x1-1)*column+y1-1);
                    Cell cell2=list.get((x2-1)*column+y2-1);
                    //Transmitter transmitter= new Transmitter(cell1,cell2);
                    //transmitters.add(transmitter);
                    if (sssss.equals("D")){
                        DeadlySnake d= new DeadlySnake(cell1,cell2);
                        cell1.setDeadlySnake(d); //اضافه
                        transmitters.add(d);
                    }
                    if (sssss.equals("E")){
                        Earthworm e= new Earthworm(cell1,cell2);
                        cell1.setEarthworm(e); //اضافه
                        transmitters.add(e);
                    }
                    if (sssss.equals("M")){
                        MagicSnake m= new MagicSnake(cell1,cell2);
                        cell1.setMagicSnake(m); //اضافه
                        transmitters.add(m);
                    }
                    if (sssss.equals("T")){
                        Transmitter transmitter= new Transmitter(cell1,cell2);
                        cell1.setTransmitter(transmitter); //اضافه
                        transmitters.add(transmitter);
                    }
                }
                if (a==row+8+tedadmohre+tedaddivar+tedadmar){
                    String o= s.substring(8);
                    tedadjayeze=Integer.parseInt(o.substring(0,o.indexOf(' ')));
                }
                if (a>row+8+tedadmohre+tedaddivar+tedadmar && a<row+9+tedadmohre+tedaddivar+tedadmar+tedadjayeze){
                    String t1= s.substring(0, s.indexOf(' '));
                    int x1= Integer.parseInt(t1);
                    String ss= s.substring(s.indexOf(' ')+1);
                    String t2= ss.substring(0,ss.indexOf(' '));
                    int y1= Integer.parseInt(t2);
                    String sss= ss.substring(ss.indexOf(' ')+1);
                    String t3= sss.substring(0,sss.indexOf(' '));
                    int point1= Integer.parseInt(t3);
                    String ssss= sss.substring(sss.indexOf(' ')+1);
                    String t4= ssss.substring(0,ssss.indexOf(' '));
                    int chance= Integer.parseInt(t4);
                    String sssss= ssss.substring(ssss.indexOf(' ')+1);
                    int dicenumb= Integer.parseInt(sssss);
                    list.get((x1-1)*column+y1-1).setPrize(new Prize(list.get((x1-1)*column+y1-1),point1,chance,dicenumb));
                }
                a=a+1;
            }
            scanner.close();

            // Code Here

            for (Cell c: list) {
                for (Transmitter t: transmitters) {
                    if (c.getX()==t.getFirstCell().getX() && c.getY()==t.getFirstCell().getY()){
                        c.setTransmitter(t);
                    }
                }
                List<Cell> ad= new ArrayList<>();
                for (int i = 0; i < list.size(); i++) {
                    Cell cell= list.get(i);
                    if (cell.getX() == c.getX() && cell.getY() == c.getY() + 1) {
                        ad.add(cell);
                    }
                    if (cell.getX() == c.getX() && cell.getY() == c.getY() - 1) {
                        ad.add(cell);
                    }
                    if (cell.getX() == c.getX() + 1 && cell.getY() == c.getY()) {
                        ad.add(cell);
                    }
                    if (cell.getX() == c.getX() - 1 && cell.getY() == c.getY()) {
                        ad.add(cell);
                    }
                }
                c.getAdjacentCells().addAll(ad);
                List<Cell> adjopencell= c.getAdjacentCells();
                List<Cell> ado= new ArrayList<>();
                for (Cell c1: c.getAdjacentCells()) {
                    for (Wall w: walls) {
                        if ((w.getCell1().equals(c) && w.getCell2().equals(c1)) || (w.getCell1().equals(c1) && w.getCell2().equals(c))){
                            ado.add(c1);
                        }
                    }
                }
                adjopencell.removeAll(ado);
                c.getAdjacentOpenCells().addAll(adjopencell);
            }

            Board board0 = new Board();
            board0.getCells().addAll(list);
            board0.getStartingCells().putAll(map);
            board0.getTransmitters().addAll(transmitters);
            board0.getWalls().addAll(walls);
            return board0;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
            System.err.println("could not find board file");
            System.exit(-2);
        }
        return null;
    }

    /**
     * load player.
     * if no such a player exist, create an account(file) for him/her.
     * <p>
     * you can use "savePlayer" method of this class for that purpose.
     * <p>
     * add your codes in "try" block .
     */
    public Player loadPlayer(String name, int playerNumber) {
        try {
            Player p;
            int tedadfile=0;
            if (Objects.requireNonNull(this.playersDirectory.listFiles()).length!=0){
                for (File f: Objects.requireNonNull(this.playersDirectory.listFiles())) {
                tedadfile=tedadfile+1;
                }
            }

            File playerFile = getPlayerFile(name);

            if (playerFile!=null) {
                Scanner s= new Scanner(playerFile);
                LinkedList<String> ll= new LinkedList<>();
                while (s.hasNext()){
                    String s2= s.nextLine();
                    ll.add(s2);
                }
                s.close();
                int score= Integer.parseInt(ll.get(1));
                int id= Integer.parseInt(ll.get(2));
                p= new Player(name,score,id,playerNumber);
                //this.savePlayer(p);
            }
            else {
                int score= 0;
                int id=tedadfile+1;
                p= new Player(name,score,id,playerNumber);
                this.savePlayer(p);
            }
            // Code in this part
            return p;
        }
        catch (FileNotFoundException | IllegalArgumentException e) {
            e.printStackTrace();
            System.err.println("could not find player file");
            System.exit(-2);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * if player does not have a file, create one.
     * <p>
     * else update his/her file.
     * <p>
     * add your codes in "try" block .
     */
    public void savePlayer(Player player) {
        try {
            File file = getPlayerFile(player.getName());
            if (file!=null){
                Scanner scanner = new Scanner(file);
                int satr =0;
                int score=0;
                while (scanner.hasNext()){
                    String s=scanner.nextLine();
                    if (satr==1){
                        score=Integer.parseInt(s);
                    }
                    satr=satr+1;
                }
                FileOutputStream fout= new FileOutputStream(file,false);
                PrintStream out= new PrintStream(fout);
                out.println(player.getName());
                out.println(player.getScore()+score);
                out.println(player.getId());
                out.flush();
                out.close();
            }
            else {
                String path1= this.playersDirectory.getPath()+"\\"+player.getName()+".txt";
                File f1= new File(path1);
                f1.getParentFile().mkdirs();
                if (!f1.exists()){
                    f1.createNewFile();
                }
                FileOutputStream fout= new FileOutputStream(f1,false);
                PrintStream out= new PrintStream(fout);
                out.println(player.getName());
                out.println(player.getScore());
                out.println(player.getId());
                out.flush();
                out.close();
            }
            //PrintStream printStream = new PrintStream(new FileOutputStream(file));
            // add your codes in this part
            //File file = getPlayerFile(player.getName());
            //PrintStream printStream = new PrintStream(new FileOutputStream(file));
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
            System.err.println("could not find player file");
            System.exit(-2);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * give you a name (player name), search for its file.
     * return the file if exist.
     * return null if not.
     */
    private File getPlayerFile(String name) throws IOException {
        //file.createNewFile();
        File fa= null;
        for (File f: Objects.requireNonNull(this.playersDirectory.listFiles())) {
            if (f.getName().equals(name)){
                fa=f;
                break;
            }
        }
        return fa;
    }

    /**
     * at the end of the game save game details
     */
    public void archive(Player player1, Player player2) {
        try {
            String winnername="";
            if (player1.getScore()>player2.getScore()){winnername=player1.getName();}
            if (player1.getScore()<player2.getScore()){winnername=player2.getName();}
            if (player1.getScore()==player2.getScore()){winnername="The game ended in a draw.";}
            FileOutputStream fout= new FileOutputStream(this.archiveFile,true);
            PrintStream out= new PrintStream(fout);
            out.println(player1.getName()+" "+player1.getScore());
            out.println(player2.getName()+" "+player2.getScore());
            out.println(winnername);
            out.flush();
            out.close();
            // add your codes in this part
            PrintStream printStream = new PrintStream(new FileOutputStream(archiveFile, true));
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
