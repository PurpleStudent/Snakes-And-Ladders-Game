package ir.sharif.math.bp99_1.snake_and_ladder.model.pieces;

import ir.sharif.math.bp99_1.snake_and_ladder.model.*;

import java.util.LinkedList;

public class Piece {
    protected Cell currentCell;
    protected final Color color;
    protected final Player player;
    protected boolean isSelected;

    protected boolean isDead;

    public Piece(Player player, Color color) {
        this.color = color;
        this.player = player;
    }

    public Player getPlayer() {
        return player;
    }

    public Color getColor() {
        return color;
    }

    public Cell getCurrentCell() {
        return currentCell;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    public void setCurrentCell(Cell currentCell) {
        this.currentCell = currentCell;
    }

    public boolean isDead() {
        return isDead;
    }
    public void setDead(boolean dead) {
        isDead = dead;
    }

    public void KillThePiece(){
        if (!this.getColor().equals(Color.GREEN)){
            this.setDead(true);
            if (this.getColor().equals(Color.RED)){this.getPlayer().getBomberPiece().setBombing(false);}
            if (this.getColor().equals(Color.BLUE)){this.getPlayer().getThiefPiece().setStealing(false);}
            if (this.getColor().equals(Color.YELLOW)){this.getPlayer().getSniperPiece().setSniping(false);}
        }
    }

    /**
     * @return "true" if your movement is valid  , else return " false"
     * <p>
     * In this method, you should check if the movement is valid of not.
     * <p>
     * You can use some methods ( they are recommended )
     * <p>
     * 1) "canEnter" method in class "Cell"
     * <p>
     * if your movement is valid, return "true" , else return " false"
     */
    public boolean isValidMove(Cell destination, int diceNumber, Board board) { //+board
        LinkedList<Boolean> move= new LinkedList<>();
        Cell c= this.getCurrentCell();
        Cell destination1= board.getCell(c.getX()+diceNumber,c.getY());
        Cell destination2= board.getCell(c.getX()-diceNumber,c.getY());
        Cell destination3= board.getCell(c.getX(),c.getY()+diceNumber);
        Cell destination4= board.getCell(c.getX(),c.getY()-diceNumber);
        boolean validmove1=true ;
        boolean validmove2=true ;
        boolean validmove3=true ;
        boolean validmove4=true ;
        if (!(destination1==null)) {
            if (destination1.equals(destination)) {
                for (int j = 0; j < diceNumber; j++) {
                    if (!(board.getCell(c.getX() + j, c.getY()).getAdjacentOpenCells().contains((board.getCell(c.getX() + j + 1, c.getY()))))) {
                        validmove1 = false;
                        break;
                    }
                }
            }
            else {validmove1=false;}
        }
        else {validmove1=false;}
        move.add(validmove1);
        if (!(destination2==null)) {
            if (destination2.equals(destination)) {
                for (int j = 0; j < diceNumber; j++) {
                    if (!(board.getCell(c.getX() - j, c.getY()).getAdjacentOpenCells().contains((board.getCell(c.getX() - j - 1, c.getY()))))) {
                        validmove2 = false;
                        break;
                    }
                }
            }
            else {validmove2=false;}
        }
        else {validmove2=false;}
        move.add(validmove2);
        if (!(destination3==null)) {
            if (destination3.equals(destination)) {
                for (int j = 0; j < diceNumber; j++) {
                    if (!(board.getCell(c.getX(), c.getY() + j).getAdjacentOpenCells().contains((board.getCell(c.getX(), c.getY() + j + 1))))) {
                        validmove3 = false;
                        break;
                    }
                }

            }
            else {validmove3=false;}
        }
        else {validmove3=false;}
        move.add(validmove3);
        if (!(destination4==null)) {
            if (destination4.equals(destination)) {
                for (int j = 0; j < diceNumber; j++) {
                    if (!(board.getCell(c.getX(), c.getY() - j).getAdjacentOpenCells().contains((board.getCell(c.getX(), c.getY() - j - 1))))) {
                        validmove4 = false;
                        break;
                    }
                }
            }
            else {validmove4=false;}
        }
        else {validmove4=false;}
        move.add(validmove4);

        boolean a1;
        a1= move.contains(true);
        boolean a2;
        if (destination==null){a2=false;}
        else {a2= destination.canEnter(this);}
        boolean a3;
        a3= !this.isDead;
        return  a1&&a2&&a3;
    }
    /**
     * @param destination move selected piece from "currentCell" to "destination"
     */
    public void moveTo(Cell destination) {
        this.getCurrentCell().setPiece(null);
        this.setCurrentCell(destination);
        destination.setPiece(this);
        if (this.getColor().equals(destination.getColor())){this.getPlayer().setScore(this.getPlayer().getScore()+4);}
        this.setSelected(false);
    }
}
