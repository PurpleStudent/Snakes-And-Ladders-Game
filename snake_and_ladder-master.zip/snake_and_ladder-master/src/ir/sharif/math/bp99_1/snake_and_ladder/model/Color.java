package ir.sharif.math.bp99_1.snake_and_ladder.model;


/**
 * DO NOT MAKE ANY CHANGE IN THIS CLASS
 */
public enum Color {
    RED,
    BLUE,
    GREEN,
    YELLOW,
    WHITE,
    BLACK
}
