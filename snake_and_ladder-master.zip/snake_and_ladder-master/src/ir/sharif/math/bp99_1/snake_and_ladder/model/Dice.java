package ir.sharif.math.bp99_1.snake_and_ladder.model;


import java.util.Random;

public class Dice {
    private int chance1;
    private int chance2;
    private int chance3;
    private int chance4;
    private int chance5;
    private int chance6;
    /**
     * add some fields to store :
     * 1) chance of each dice number ( primary chance of each number, should be 1 )
     * currently our dice has 1 to 6.
     * 2) generate a random number
     * <p>
     * initialize these fields in constructor.
     */
    public Dice() {
        this.chance1= 1;
        this.chance2= 1;
        this.chance3= 1;
        this.chance4= 1;
        this.chance5= 1;
        this.chance6= 1;
    }

    public int getChance1() {
        return chance1;
    }
    public void setChance1(int chance1) {
        this.chance1 = chance1;
    }

    public int getChance2() {
        return chance2;
    }
    public void setChance2(int chance2) {
        this.chance2 = chance2;
    }

    public int getChance3() {
        return chance3;
    }
    public void setChance3(int chance3) {
        this.chance3 = chance3;
    }

    public int getChance4() {return chance4;}
    public void setChance4(int chance4) {
        this.chance4 = chance4;
    }

    public int getChance5() {
        return chance5;
    }
    public void setChance5(int chance5) {
        this.chance5 = chance5;
    }

    public int getChance6() {
        return chance6;
    }
    public void setChance6(int chance6) {
        this.chance6 = chance6;
    }

    /**
     * create an algorithm generate a random number(between 1 to 6) according to the
     * chance of each dice number( you store them somewhere)
     * return the generated number
     */
    public int roll() {
        Random r=new Random();
        int sum=chance1+chance2+chance3+chance4+chance5+chance6;
        int a=r.nextInt(sum);
        int b=0;
        if (a<chance1){
            b= 1;}
        if (chance1<=a && a<chance1+chance2){
            b= 2;}
        if (chance1+chance2<=a && a<chance1+chance2+chance3){
            b= 3;}
        if (chance1+chance2+chance3<=a && a<chance1+chance2+chance3+chance4){
            b= 4;}
        if (chance1+chance2+chance3+chance4<=a && a<chance1+chance2+chance3+chance4+chance5){
            b= 5;}
        if (chance1+chance2+chance3+chance4+chance5<=a && a<chance1+chance2+chance3+chance4+chance5+chance6){
            b= 6;}
        return b;
    }

    /**
     * give a dice number and a chance, you should UPDATE chance
     * of that number.
     * pay attention chance of none of the numbers must not be negetive(it can be zero)
     */
    public void addChance(int number, int chance) {
        if (number==1){
            this.chance1 = Math.min(this.chance1 + chance, 8);
        }
        if (number==2){
            this.chance2 = Math.min(this.chance2 + chance, 8);
        }
        if (number==3){
            this.chance3 = Math.min(this.chance3 + chance, 8);
        }
        if (number==4){
            this.chance4 = Math.min(this.chance4 + chance, 8);
        }
        if (number==5){
            this.chance5 = Math.min(this.chance5 + chance, 8);
        }
        if (number==6){
            this.chance6 = Math.min(this.chance6 + chance, 8);
        }
    }


    /**
     * you should return the details of the dice number.
     * sth like:
     * "1 with #1 chance.
     * 2 with #2 chance.
     * 3 with #3 chance
     * .
     * .
     * . "
     * where #i is the chance of number i.
     */
    public String getDetails() {
        return "chance1="+chance1+" ,chance2="+chance2+" ,chance3="+chance3+" ,chance4="+chance4+" ,chance5="+chance5+" ,chance6="+chance6;
    }
}
