package ir.sharif.math.bp99_1.snake_and_ladder.model.pieces;

import ir.sharif.math.bp99_1.snake_and_ladder.model.Board;
import ir.sharif.math.bp99_1.snake_and_ladder.model.Cell;
import ir.sharif.math.bp99_1.snake_and_ladder.model.Color;
import ir.sharif.math.bp99_1.snake_and_ladder.model.Player;
import ir.sharif.math.bp99_1.snake_and_ladder.model.prizes.Prize;

import java.util.LinkedList;

public class ThiefPiece extends Piece {
    private boolean Stealing;
    private Prize prize;
    public ThiefPiece(Player player, Color color) {
        super(player, color);
        this.Stealing= true;
        this.prize= null;
    }
    public boolean isStealing() {return Stealing;}
    public void setStealing(boolean stealing) {this.Stealing = stealing;}

    public Prize getPrize(){return prize;}
    public void setPrize(Prize prize){this.prize = prize;}

    public void KillThePiece(){
        super.KillThePiece();
        this.setStealing(false);
    }

    public boolean isValidMove(Cell destination, int diceNumber, Board board){
        LinkedList<Boolean> move= new LinkedList<>();
        Cell c= this.getCurrentCell();
        Cell destination1= board.getCell(c.getX()+diceNumber,c.getY());
        Cell destination2= board.getCell(c.getX()-diceNumber,c.getY());
        Cell destination3= board.getCell(c.getX(),c.getY()+diceNumber);
        Cell destination4= board.getCell(c.getX(),c.getY()-diceNumber);
        boolean validmove1=true ;
        boolean validmove2=true ;
        boolean validmove3=true ;
        boolean validmove4=true ;
        if (!(destination1==null)) {
            validmove1= destination1.equals(destination);
        }
        else {validmove1=false;}
        move.add(validmove1);
        if (!(destination2==null)) {
            validmove2= destination2.equals(destination);
        }
        else {validmove2=false;}
        move.add(validmove2);
        if (!(destination3==null)) {
            validmove3= destination3.equals(destination);
        }
        else {validmove3=false;}
        move.add(validmove3);
        if (!(destination4==null)) {
            validmove4= destination4.equals(destination);
        }
        else {validmove4=false;}
        move.add(validmove4);

        boolean a1;
        a1= move.contains(true);
        boolean a2;
        if (destination==null){a2=false;}
        else {a2= destination.getPiece() == null;}
        return  a1&&a2;
    }

    public void moveTo(Cell destination){
        super.moveTo(destination);

        this.getCurrentCell().setThiefPiece(null);
        destination.setThiefPiece(this);
    }
}
